#'Charlson Comorbidity Index
#'
#'@description Computes a modified version of the Charlson Comorbidity Index (CCI) that was adapted for use with administrative data (e.g. diagnoses codes from electronic health records).
#'By default, the function will calculate the score using the method described by Quan et.al.
#'by classifying and/or weighting comorbidities as defined by diagnosis codes (ICD9 and ICD10),
#'This function is optimized to integrate two data frames:
#'A set of patients with or without a defined start and stop date and a set of diagnosis codes that can be linked to the patient set by an identifier such as "MRN." The ICD file must contain separate columns for ICD9 and ICD10 codes and the corresponding date for each code.
#'The function searches for patients in the ICD data frame, indexes comorbidities that occur between the st.date and end.date, computes the CCI, and attaches the value to the patient data frame.
#'
#'
#'@param patients A data frame of patients that must contain a column with the unique identifier (MRN - ID.patients) for whom to calculate CCI. May contain st.date and end.date
#'@param diagcodes A data frame of ICD codes that must contain a diagnosis date (dx.date), ICD9 codes (dx.diagcodes), ICD10 codes (dx.diagcodes2) and a patient identifier (MRN - ID.diagcodes) that matches the identifier in patient data frame
#'@param ID.patients A character column name, patient identifier in data frame patients that matches the identifier in data frame ICD. Common name includes patient "MRN","PAT_MRN_ID", or "PAT_MRN". Default is "PAT_MRN_ID".
#'@param ID.diagcodes A character column name, patient identifier in data frame ICD that matches the identifier in data frame patients. Common name includes patient "MRN","PAT_MRN_ID", or "PAT_MRN". Default is "PAT_MRN_ID".
#'@param dx.diagcodes A character column name of ICD9 codes (ICD9 only, omits ICD10 codes.) ICD9 and ICD10 codes must be separate columns.
#'@param dx.diagcodes2 A character column name of ICD10 codes (ICD10 only, omits ICD9 codes.) ICD9 and ICD10 codes must be separate columns.
#'@param dx.date A column name of diagnosis date of the ICD codes. Default is "DX_DATE", unless otherwise given. Class must be Date.
#'@param st.date A column name (class Date) in patients data frame or value that defines beginning date for which ICD codes should be included in the calculation. The default "1800-01-01" will include all observation in the ICD data frame. Date format "4 digit year-2 digit month-2 digit day".
#'@param end.date A column name (class Date) in patients data frame or value that defines end date for which ICD codes should be included in the calculation. The default "3000-01-01",
#'will include all observation in the ICD data frame. Date format "4 digit year-2 digit month-2 digit day".
#'@param weights The method for weighting. The default method, "original" is recommended. "quan" and "schneeweiss" are also available. Only one method can be defined
#'@param method The method to be used for CCI calculation.  The default method,"quan" is recommended. "deyo" is also available. Only one method can be defined
#'@return CCIo: A numeric column of CCI values attached to data frame patients.
#'@author Kristin Lenoir \email{klenoir@wakehealth.edu}
#'@description If ID.patients is not in Id.diagcodes file, return CCIo value is 0. If dx.date is NA, the corresponding ICD code will be excluded from analysis.
#'Solution is to replace dx.date NA values with Sys.Date().
#'ICD files are often notably large, so please allow at least 30 minutes of processing time.
#'@keywords CCI, Charlson Comorbidity Index
#'@references

#'Methods:
#'
#'Quan H, Sundararajan V, Halfon P, Fong A, Burnand B, Luthi J-C, et al.
#'Coding algorithms for defining comorbidities in ICD-9-CM and ICD-10 administrative data. Medical care. 2005;1130-1139.
#'
#'Deyo RA, Cherkin DC, Ciol MA. Adapting a clinical comorbidity index for use with ICD-9-CM administrative databases. J Clin Epidemiol. 1992 Jun;45(6):613-9.
#'
#Weights
#'Quan vs. Original:
#'
#'Quan H, Li B, Couris CM, Fushimi K, Graham P, Hider P, et al.
#'Updating and Validating the Charlson Comorbidity Index and Score for Risk Adjustment in Hospital Discharge Abstracts Using Data From 6 Countries. American Journal of Epidemiology. 2011 Mar 15;173(6):676-82.
#'
#'Schneeweiss vs. Original:
#'
#'Schneeweiss S, Wang PS, Avorn J, Glynn RJ. Improved Comorbidity Adjustment for
#'Predicting Mortality in Medicare Populations. Health Serv Res. 2003 Aug;38(4):1103-20.

#'@examples
#'#format as date for both data sets
#'icd$date<-as.Date(icd$MYDATE, format="%m/%d/%Y")
#'#get date only from date/time
#'patient$date<-as.Date(as.POSIXlt(strptime(patient$ADMIT_DATE, "%m/%d/%Y %H:%M")))
#'
#'#Calculate CCI for all diagnosis codes in icd file before or on "date"
#'CCIexample1<-CCI(patient, icd, ID.patients="DI_MRN", ID.diagcodes="DI_MRN",
#'                  dx.date="date", weights="original", method="quan")
#'
#'#Calculate CCI for all diagnosis codes in icd file
#'#between "2013-01-01" through "2014-01-01" with quan weights
#'CCIexample2<-CCI(patient, icd, ID.patients="DI_MRN", ID.diagcodes="DI_MRN",
#'              st.date="2012-01-01", end.date="2014-01-01",dx.date="date",
#'              weights="quan", method="quan")
#'
#'#Calculate CCI for diagnosis codes before or on admit date, original weights with deyo method
#'CCIexample3<-CCI(patient, icd, ID.patients="DI_MRN", ID.diagcodes="DI_MRN",
#'              end.date="date",dx.date="date",
#'              weights="original", method="deyo")
#'
#'#Make data set of patients from icd codes to calculate CCI - if only have icd list
#'icdnew<-icd[order(icd$date,decreasing=T),] #order by most recent icd date
#'icdnew<-icdnew[!duplicated(icdnew$DI_MRN),] #get unique MRN for most recent icd code instance
#'patientsnew<-icdnew[,c("DI_MRN","date")] #only get MRN and date columns
#'#Calculate CCI for each MRN for all icd codes
#'CCIexamplenew<-CCI(patients=patientsnew, icd, ID.patients="DI_MRN", ID.diagcodes="DI_MRN",
#'                  dx.date="date", weights="original", method="quan")


#'@export

CCI<-function(patients, diagcodes, ID.patients="PAT_MRN_ID", ID.diagcodes="PAT_MRN_ID", dx.diagcodes="DIAGNOSIS_CODE_9",
              dx.diagcodes2="DIAGNOSIS_CODE_10", dx.date="DX_DATE", st.date="1800-01-01", end.date="3000-01-01",
              weights=c("original", "quan", "schneeweiss"), method=c("quan", "deyo")){

  ## Get diagnosis codes only of the patient population
  diagcodes<-diagcodes[(diagcodes[,ID.diagcodes] %in% patients[,ID.patients]),]

  ## Holding variable
  temp<-patients

  if(method=="quan"){
    ## These are regular expression codes that we are interested in separated out into ICD9 or ICD10 to be checked separately
    mi.codes<-c("410", "412")
    mi.codes2<-c("I21", "I22", "I25.2")
    ## Find the regular expression codes
    diagcodes$mi<-sapply(1:nrow(diagcodes), function (x) grepl(paste(mi.codes, collapse="|"), diagcodes[x,dx.diagcodes], ignore.case=T))
    diagcodes$mi2<-sapply(1:nrow(diagcodes), function (x) grepl(paste(mi.codes2, collapse="|"), diagcodes[x,dx.diagcodes2], ignore.case=T))
    ## Get all of the codes that we found to be MI
    mi.patients<-diagcodes[diagcodes$mi==T | diagcodes$mi2==T,]
    ## Order the codes by diagnosis ID and oldest diagnosis date
    mi.patients<-mi.patients[order(mi.patients[,ID.diagcodes], mi.patients[,dx.date], decreasing=F),]  #
    ## Take the first instance of the diagnosis
    mi.patients<-mi.patients[duplicated(mi.patients[,ID.diagcodes])==F,]
    ## In the holding variable, create holding column to later check whether or not the patient had a diagnosis at that time
    temp$mi<-ifelse(temp[,ID.patients] %in% mi.patients[,ID.diagcodes],T,F)
    ## Reduce the data frame of diagnosis codes to those that aren't found to be MI so that it will process faster
    #diagcodes<-diagcodes[diagcodes$mi==F,]
	#diagcodes<-diagcodes[diagcodes$mi2==F,]


	#####
	#CHF#
	#####
    chf.codes<-c("428",
				"398.91", "402.01", "402.11", "402.91", "404.01", "404.03", "404.11", "404.13",
				"404.91", "404.93", "425.4", "425.5", "425.6", "425.7", "425.8", "425.9")
    chf.codes2<-c("I43", "I50",
				"P29.0", "I42.5", "I42.6", "I42.7", "I42.8", "I42.9",
				"I42.0", "I25.5", "I13.2", "I13.0", "I11.0", "I09.9")
    diagcodes$chf<-sapply(1:nrow(diagcodes), function (x) grepl(paste(chf.codes, collapse="|"), diagcodes[x,dx.diagcodes], ignore.case=T))
    diagcodes$chf2<-sapply(1:nrow(diagcodes), function (x) grepl(paste(chf.codes2, collapse="|"), diagcodes[x,dx.diagcodes2], ignore.case=T))
    chf.patients<-diagcodes[diagcodes$chf==T | diagcodes$chf2==T,]
    chf.patients<-chf.patients[order(chf.patients[,ID.diagcodes], chf.patients[,dx.date], decreasing=F),]
    all.chf.patients<-chf.patients[duplicated(chf.patients[,ID.diagcodes])==F,]
    temp$chf<-ifelse((temp[,ID.patients] %in% chf.patients[,ID.diagcodes]),T,F)
	#diagcodes<-diagcodes[diagcodes$chf==F,]
	#diagcodes<-diagcodes[diagcodes$chf2==F,]

	######
	#PVD##  #443.1 all was not specified correctly
	######
    pvd.codes<-c("440", "441",
		 "437.3", "093.0","443.1","443.2", "443.3", "443.4", "443.5", "443.6", "443.7", "443.8", "443.9",
		 "557.1", "557.9",
		"447.1", "V43.4")
    pvd.codes2<-c("I70", "I71", "I73.8", "I79.2", "Z95.8",   #no such code I79.2 exists in ICD10
			"I73.1", "I73.9", "I77.1", "I79.0",
			"I79.2",
			"K55.1", "K55.8",
			"K55.9", "Z95.9")
    diagcodes$pvd<-sapply(1:nrow(diagcodes), function (x) grepl(paste(pvd.codes, collapse="|"), diagcodes[x,dx.diagcodes], ignore.case=T))
    diagcodes$pvd2<-sapply(1:nrow(diagcodes), function (x) grepl(paste(pvd.codes2, collapse="|"), diagcodes[x,dx.diagcodes2], ignore.case=T))
    pvd.patients<-diagcodes[diagcodes$pvd==T | diagcodes$pvd2==T,]
    pvd.patients<-pvd.patients[order(pvd.patients[,ID.diagcodes], pvd.patients[,dx.date], decreasing=F),]
	all.pvd.patients<-pvd.patients[duplicated(pvd.patients[,ID.diagcodes])==F,]
    temp$pvd<-ifelse((temp[,ID.patients] %in% pvd.patients[,ID.diagcodes]),T,F)
	#diagcodes<-diagcodes[diagcodes$pvd==F,]
	#diagcodes<-diagcodes[diagcodes$pvd2==F,]
	####
	#CD#
	####
    cd.codes<-c("362.34", "430", "431", "432", "433", "434", "435", "436", "437", "438")
    cd.codes2<-c("G45", "G46", "H34.0", "I60", "I61", "I62", "I63", "I64", "I65", "I66", "I67", "I68", "I69")
    diagcodes$cd<-sapply(1:nrow(diagcodes), function (x) grepl(paste(cd.codes, collapse="|"), diagcodes[x,dx.diagcodes], ignore.case=T))
    diagcodes$cd2<-sapply(1:nrow(diagcodes), function (x) grepl(paste(cd.codes2, collapse="|"), diagcodes[x,dx.diagcodes2], ignore.case=T))
    cd.patients<-diagcodes[diagcodes$cd==T | diagcodes$cd2==T,]
    cd.patients<-cd.patients[order(cd.patients[,ID.diagcodes], cd.patients[,dx.date], decreasing=F),]
    cd.patients<-cd.patients[duplicated(cd.patients[,ID.diagcodes])==F,]
    temp$cd<-ifelse(temp[,ID.patients] %in% cd.patients[,ID.diagcodes],T,F)
    #diagcodes<-diagcodes[diagcodes$cd==F,]
	#diagcodes<-diagcodes[diagcodes$cd2==F,]
	######################

	#############
    dementia.codes<-c("290",
					  "331.2","294.1")
    dementia.codes2<-c("G30",  "F00", "F01", "F02", "F03",
						"F05.1", "G31.1")
    diagcodes$dementia<-sapply(1:nrow(diagcodes), function(x) grepl(paste(dementia.codes, collapse="|"), diagcodes[x,dx.diagcodes], ignore.case=T))
    diagcodes$dementia2<-sapply(1:nrow(diagcodes), function(x) grepl(paste(dementia.codes2, collapse="|"), diagcodes[x,dx.diagcodes2], ignore.case=T))
    dementia.patients<-diagcodes[diagcodes$dementia==T | diagcodes$dementia2==T,]
    dementia.patients<-dementia.patients[order(dementia.patients[,ID.diagcodes], dementia.patients[,dx.date], decreasing=F),]
    all.dementia.patients<-dementia.patients[duplicated(dementia.patients[,ID.diagcodes])==F,]
    temp$dementia<-ifelse((temp[,ID.patients] %in% dementia.patients[,ID.diagcodes]),T,F)
	#diagcodes<-diagcodes[diagcodes$dementia==F, ]
	#diagcodes<-diagcodes[diagcodes$dementia2==F,]

	#######
	#COPD##
	#######
    cpd.codes<-c("490", "491", "492", "493", "494", "495", "496", "497", "498", "499", "500", "501", "502", "503", "504", "505",
				"416.8", "416.9", "506.4", "508.1", "508.8")
    cpd.codes2<-c("I27.8", "J40", "J41", "J42", "J43", "J44", "J45", "J46", "J47", "J60", "J61", "J62", "J63", "J64", "J65", "J66", "J67",
				"I27.9", "J68.4", "J70.1", "J70.3")
    diagcodes$cpd<-sapply(1:nrow(diagcodes), function (x) grepl(paste(cpd.codes, collapse="|"), diagcodes[x,dx.diagcodes], ignore.case=T))
    diagcodes$cpd2<-sapply(1:nrow(diagcodes), function (x) grepl(paste(cpd.codes2, collapse="|"), diagcodes[x,dx.diagcodes2], ignore.case=T))
    cpd.patients<-diagcodes[diagcodes$cpd==T | diagcodes$cpd2==T,]
    cpd.patients<-cpd.patients[order(cpd.patients[,ID.diagcodes], cpd.patients[,dx.date], decreasing=F),]
    all.cpd.patients<-cpd.patients[duplicated(cpd.patients[,ID.diagcodes])==F,]
    temp$cpd<-ifelse((temp[,ID.patients] %in% cpd.patients[,ID.diagcodes]),T,F)
    #diagcodes<-diagcodes[diagcodes$cpd==F,]
	#diagcodes<-diagcodes[diagcodes$cpd2==F,]

	####
	#RD#
	####
    rd.codes<-c("714.8", "725",
				"446.5", "710.0", "710.1", "710.2", "710.3", "710.4",
				"714.0", "714.1", "714.2")
    rd.codes2<-c("M05", "M06", "M32", "M33", "M34",
			"M31.5", "M35.1", "M35.3", "M36.0")
    diagcodes$rd<-sapply(1:nrow(diagcodes), function (x) grepl(paste(rd.codes, collapse="|"), diagcodes[x,dx.diagcodes], ignore.case=T))
    diagcodes$rd2<-sapply(1:nrow(diagcodes), function (x) grepl(paste(rd.codes2, collapse="|"), diagcodes[x,dx.diagcodes2], ignore.case=T))
    rd.patients<-diagcodes[diagcodes$rd==T | diagcodes$rd2==T,]
    rd.patients<-rd.patients[order(rd.patients[,ID.diagcodes], rd.patients[,dx.date], decreasing=F),]
    all.rd.patients<-rd.patients[duplicated(rd.patients[,ID.diagcodes])==F,]
    temp$rd<-ifelse((temp[,ID.patients] %in% rd.patients[,ID.diagcodes]),T,F)
    #diagcodes<-diagcodes[diagcodes$rd==F,]
	#diagcodes<-diagcodes[diagcodes$rd2==F,]

	#####
	#PUD#
	#####
    pud.codes<-c("531", "532", "533", "534")
    pud.codes2<-c("K25", "K26", "K27", "K28")
    diagcodes$pud<-sapply(1:nrow(diagcodes), function (x) grepl(paste(pud.codes, collapse="|"), diagcodes[x,dx.diagcodes], ignore.case=T))
    diagcodes$pud2<-sapply(1:nrow(diagcodes), function (x) grepl(paste(pud.codes2, collapse="|"), diagcodes[x,dx.diagcodes2], ignore.case=T))
    pud.patients<-diagcodes[diagcodes$pud==T | diagcodes$pud2==T,]
    pud.patients<-pud.patients[order(pud.patients[,ID.diagcodes], pud.patients[,dx.date], decreasing=F),]
    pud.patients<-pud.patients[duplicated(pud.patients[,ID.diagcodes])==F,]
    temp$pud<-ifelse(temp[,ID.patients] %in% pud.patients[,ID.diagcodes],T,F)
    #diagcodes<-diagcodes[diagcodes$pud==F,]
	 #diagcodes<-diagcodes[diagcodes$pud2==F,]

	#####
	#MLD#
	#####
    mld.codes<-c("570", "571",
		"070.22", "070.23", "070.32", "070.33", "070.44",
		"070.54", "070.6", "070.9", "573.3", "573.4", "573.8",
		"573.9", "V42.7")
	mld.codes2<-c("B18", "K73", "K74", "K76.8", "K70.1", "K70.3", "K71.5","Z94.4",
			"K76.0", "K76.2", "K76.3", "K76.4", "Z94.4", "K76.9",
			"K71.7", "K70.0", "K70.2", "K70.9", "K71.3", "K71.4")
    diagcodes$mld<-sapply(1:nrow(diagcodes), function (x) grepl(paste(mld.codes, collapse="|"), diagcodes[x,dx.diagcodes], ignore.case=T))
    diagcodes$mld2<-sapply(1:nrow(diagcodes), function (x) grepl(paste(mld.codes2, collapse="|"), diagcodes[x,dx.diagcodes2], ignore.case=T))
    mld.patients<-diagcodes[diagcodes$mld==T | diagcodes$mld2==T,]
    mld.patients<-mld.patients[order(mld.patients[,ID.diagcodes], mld.patients[,dx.date], decreasing=F),]
    all.mld.patients<-mld.patients[duplicated(mld.patients[,ID.diagcodes])==F,]
    temp$mld<-ifelse((temp[,ID.patients] %in% mld.patients[,ID.diagcodes]),T,F)
    #diagcodes<-diagcodes[diagcodes$mld==F,]
	 #diagcodes<-diagcodes[diagcodes$mld2==F,]

	#########
	#DIABETES WITHOUT COMPLICATION
    diabetes.codes<-c("250.0", "250.1", "250.2", "250.3", "250.8", "250.9",
				"^250$")  #250 is diabetes, but code doesn't pick up 250.  assume less severe unless specified, which will outweigh this category)
    diabetes.codes2<-c("E10.0", "E10.1", "E10.6", "E10.8", "E10.9", "E11.0",
		"E11.1", "E11.6", "E11.8", "E11.9", "E12.0", "E12.1",
		"E12.6", "E12.8", "E12.9", "E13.0", "E13.1", "E13.6",
		"E13.8", "E13.9", "E14.0", "E14.1", "E14.6", "E14.8",
		"E14.9")
    diagcodes$diabetes<-sapply(1:nrow(diagcodes), function (x) grepl(paste(diabetes.codes, collapse="|"), diagcodes[x,dx.diagcodes], ignore.case=T))
    diagcodes$diabetes2<-sapply(1:nrow(diagcodes), function (x) grepl(paste(diabetes.codes2, collapse="|"), diagcodes[x,dx.diagcodes2], ignore.case=T))
    diabetes.patients<-diagcodes[diagcodes$diabetes==T | diagcodes$diabetes2==T,]
    diabetes.patients<-diabetes.patients[order(diabetes.patients[,ID.diagcodes], diabetes.patients[,dx.date], decreasing=F),]
     all.diabetes.patients<-diabetes.patients[duplicated(diabetes.patients[,ID.diagcodes])==F,]
    temp$diabetes<-ifelse((temp[,ID.patients] %in% diabetes.patients[,ID.diagcodes]),T,F)
    #diagcodes<-diagcodes[diagcodes$diabetes==F,]

	########
	#DIA WC#
	########
    diabeteswc.codes<-c("250.4", "250.5", "250.6", "250.7")
    diabeteswc.codes2<-c("E10.2", "E10.3", "E10.4", "E10.5", "E10.7", "E11.2", "E11.3", "E11.4", "E11.5",
                         "E11.7", "E12.2", "E12.3", "E12.4", "E12.5", "E12.7", "E13.2", "E13.3", "E13.4", "E13.5", "E13.7", "E14.2", "E14.3",
                         "E14.4", "E14.5", "E14.7")
    diagcodes$diabeteswc<-sapply(1:nrow(diagcodes), function (x) grepl(paste(diabeteswc.codes, collapse="|"), diagcodes[x,dx.diagcodes], ignore.case=T))
    diagcodes$diabeteswc2<-sapply(1:nrow(diagcodes), function (x) grepl(paste(diabeteswc.codes2, collapse="|"), diagcodes[x,dx.diagcodes2], ignore.case=T))
    diabeteswc.patients<-diagcodes[diagcodes$diabeteswc==T | diagcodes$diabeteswc2==T,] #error found, no call for diabetes wc2  only diabetes
    diabeteswc.patients<-diabeteswc.patients[order(diabeteswc.patients[,ID.diagcodes], diabeteswc.patients[,dx.date], decreasing=F),]
    diabeteswc.patients<-diabeteswc.patients[duplicated(diabeteswc.patients[,ID.diagcodes])==F,]
    temp$diabeteswc<-ifelse(temp[,ID.patients] %in% diabeteswc.patients[,ID.diagcodes],T,F)
    #diagcodes<-diagcodes[diagcodes$diabeteswc==F,]

	#########
	#HEMOPLE#
	#########
    hemiplegia.codes<-c("342", "343", "344.0", "344.3", "344.4",
			"334.1", "344.1", "344.2", "344.5", "344.6", "344.9")
    hemiplegia.codes2<-c("G81", "G82", "G83.0", "G83.1", "G83.2", "G83.3",
			"G04.1", "G11.4", "G80.1", "G80.2", "G83.4", "G83.9")
    diagcodes$hemiplegia<-sapply(1:nrow(diagcodes), function (x) grepl(paste(hemiplegia.codes, collapse="|"), diagcodes[x,dx.diagcodes], ignore.case=T))
    diagcodes$hemiplegia2<-sapply(1:nrow(diagcodes), function (x) grepl(paste(hemiplegia.codes2, collapse="|"), diagcodes[x,dx.diagcodes2], ignore.case=T))
    hemiplegia.patients<-diagcodes[diagcodes$hemiplegia==T | diagcodes$hemiplegia2==T,]
    hemiplegia.patients<-hemiplegia.patients[order(hemiplegia.patients[,ID.diagcodes], hemiplegia.patients[,dx.date], decreasing=F),]
    all.hemiplegia.patients<-hemiplegia.patients[duplicated(hemiplegia.patients[,ID.diagcodes])==F,]
    temp$hemiplegia<-ifelse((temp[,ID.patients] %in% hemiplegia.patients[,ID.diagcodes]),T,F)
    #diagcodes<-diagcodes[diagcodes$hemiplegia==F,]

	#######
	#RENAL#
	#######
    renal.codes<-c("582", "585", "586", "V45.1", "V56",
			"403.01", "403.11", "403.91", "404.02", "404.03",
		"404.12", "404.13", "404.92", "404.93", "583.0", "583.1",
		"583.2", "583.3", "583.4", "583.5", "583.6", "583.7",
		"588.0", "V42.0")
    renal.codes2<-c("I13.1", "N18", "N19", "Z49.0", "Z49.1", "Z49.2",
			"I12.0", "N03.2", "N03.3", "N03.4", "N03.5", "N03.6",
			"N03.7", "N05.2", "N05.3", "N05.4", "N05.6", "N05.7",
			"N25.0", "Z94.0", "Z99.2")
    diagcodes$renal<-sapply(1:nrow(diagcodes), function (x) grepl(paste(renal.codes, collapse="|"), diagcodes[x,dx.diagcodes], ignore.case=T))
    diagcodes$renal2<-sapply(1:nrow(diagcodes), function (x) grepl(paste(renal.codes2, collapse="|"), diagcodes[x,dx.diagcodes2], ignore.case=T))
    renal.patients<-diagcodes[diagcodes$renal==T | diagcodes$renal2==T,]
    renal.patients<-renal.patients[order(renal.patients[,ID.diagcodes], renal.patients[,dx.date], decreasing=F),]
    all.renal.patients<-renal.patients[duplicated(renal.patients[,ID.diagcodes])==F,]
    temp$renal<-ifelse((temp[,ID.patients] %in% renal.patients[,ID.diagcodes]),T,F)
    #diagcodes<-diagcodes[diagcodes$renal==F,]

	#######
	#MALIG#
	#######
    malignancy.codes<-c("140", "141", "142", "143", "144", "145", "146", "147", "148", "149", "150",
                        "151", "152", "153", "154", "155", "156", "157", "158", "159", "160", "161",
                        "162", "163", "164", "165", "166", "167", "168", "169", "170", "171", "172",
                        "174", "175", "176", "177", "178", "179", "180", "181", "182", "183", "184",
                        "185", "186", "187", "188", "189", "190", "191", "192", "193", "194", "195.0",
                        "195.1", "195.2", "195.3", "195.4", "195.5", "195.6", "195.7", "195.8", "200",
                        "201", "202", "203", "204", "205", "206", "207", "208", "238.6")
    malignancy.codes2<-c("C00", "C01", "C02", "C03", "C04", "C05", "C06", "C07", "C08", "C09", "C10",
                         "C11", "C12", "C13", "C14", "C15", "C16", "C17", "C18", "C19", "C20", "C21",
                         "C22", "C23", "C24", "C25", "C26", "C30", "C31", "C32", "C33", "C34", "C37",
                         "C38", "C39", "C40", "C41", "C43", "C45", "C46", "C47", "C48", "C49", "C50",
                         "C51", "C52", "C53", "C54", "C55", "C56", "C57", "C58", "C60", "C61", "C62",
                         "C63", "C64", "C65", "C66", "C67", "C68", "C69", "C70", "C71", "C72", "C73",
                         "C74", "C75", "C76", "C81", "C82", "C83", "C84", "C85", "C88", "C90", "C91",
                         "C92", "C93", "C94", "C95", "C96", "C97")
    diagcodes$malignancy<-sapply(1:nrow(diagcodes), function (x) grepl(paste(malignancy.codes, collapse="|"), diagcodes[x,dx.diagcodes], ignore.case=T))
    diagcodes$malignancy2<-sapply(1:nrow(diagcodes), function (x) grepl(paste(malignancy.codes2, collapse="|"), diagcodes[x,dx.diagcodes2], ignore.case=T))
    malignancy.patients<-diagcodes[diagcodes$malignancy==T | diagcodes$malignancy2==T,]
    malignancy.patients<-malignancy.patients[order(malignancy.patients[,ID.diagcodes], malignancy.patients[,dx.date], decreasing=F),]
    malignancy.patients<-malignancy.patients[duplicated(malignancy.patients[,ID.diagcodes])==F,]
    temp$malignancy<-ifelse(temp[,ID.patients] %in% malignancy.patients[,ID.diagcodes],T,F)
    #diagcodes<-diagcodes[diagcodes$malignancy==F,]

	#######
	#LIVER#
	#######
    liver.codes<-c("456.2",
			"456.0", "456.1", "572.2", "572.3", "572.4", "572.5",
			"572.6", "572.7", "572.8")
    liver.codes2<-c("I85.0", "I85.9", "I98.2", "K70.4", "K71.1", "K72.1", "K72.9",
				"I86.4", "K76.5", "K76.6", "K76.7")
    diagcodes$liver<-sapply(1:nrow(diagcodes), function (x) grepl(paste(liver.codes, collapse="|"), diagcodes[x,dx.diagcodes], ignore.case=T))
    diagcodes$liver2<-sapply(1:nrow(diagcodes), function (x) grepl(paste(liver.codes2, collapse="|"), diagcodes[x,dx.diagcodes2], ignore.case=T))
    liver.patients<-diagcodes[diagcodes$liver==T | diagcodes$liver2==T,]
    liver.patients<-liver.patients[order(liver.patients[,ID.diagcodes], liver.patients[,dx.date], decreasing=F),]
	all.liver.patients<-liver.patients[duplicated(liver.patients[,ID.diagcodes])==F,]
    temp$liver<-ifelse((temp[,ID.patients] %in% liver.patients[,ID.diagcodes]),T,F)
    #diagcodes<-diagcodes[diagcodes$liver==F,]

	#######
	#TUMOR#
	#######
    tumor.codes<-c("196", "197", "198", "199")
    tumor.codes2<-c("C77", "C78", "C79", "C80")
    diagcodes$tumor<-sapply(1:nrow(diagcodes), function (x) grepl(paste(tumor.codes, collapse="|"), diagcodes[x,dx.diagcodes], ignore.case=T))
    diagcodes$tumor2<-sapply(1:nrow(diagcodes), function (x) grepl(paste(tumor.codes2, collapse="|"), diagcodes[x,dx.diagcodes2], ignore.case=T))
    tumor.patients<-diagcodes[diagcodes$tumor==T | diagcodes$tumor2==T,]
    tumor.patients<-tumor.patients[order(tumor.patients[,ID.diagcodes], tumor.patients[,dx.date], decreasing=F),]
    tumor.patients<-tumor.patients[duplicated(tumor.patients[,ID.diagcodes])==F,]
    temp$tumor<-ifelse(temp[,ID.patients] %in% tumor.patients[,ID.diagcodes],T,F)
    #diagcodes<-diagcodes[diagcodes$tumor==F,]

	#####
	#HIV#
	#####
    HIV.codes<-c("042", "043", "044")
    HIV.codes2<-c("B20", "B21", "B22", "B24")
    diagcodes$HIV<-sapply(1:nrow(diagcodes), function (x) grepl(paste(HIV.codes, collapse="|"), diagcodes[x,dx.diagcodes], ignore.case=T))
    diagcodes$HIV2<-sapply(1:nrow(diagcodes), function (x) grepl(paste(HIV.codes2, collapse="|"), diagcodes[x,dx.diagcodes2], ignore.case=T))
    HIV.patients<-diagcodes[diagcodes$HIV==T | diagcodes$HIV2==T,]
    HIV.patients<-HIV.patients[order(HIV.patients[,ID.diagcodes], HIV.patients[,dx.date], decreasing=F),]
    HIV.patients<-HIV.patients[duplicated(HIV.patients[,ID.diagcodes])==F,]
    temp$HIV<-ifelse(temp[,ID.patients] %in% HIV.patients[,ID.diagcodes],T,F)
    #diagcodes<-diagcodes[diagcodes$HIV==F,]

}else{
######
#DEYO#
######
  if(method=="deyo"){
    mi.codes<-c("410", "412")
    mi.codes2<-c("I21", "I22", "I25.2")
    diagcodes$mi<-sapply(1:nrow(diagcodes), function (x) grepl(paste(mi.codes, collapse="|"), diagcodes[x,dx.diagcodes], ignore.case=T))
    diagcodes$mi2<-sapply(1:nrow(diagcodes), function (x) grepl(paste(mi.codes2, collapse="|"), diagcodes[x,dx.diagcodes2], ignore.case=T))
    mi.patients<-diagcodes[diagcodes$mi==T | diagcodes$mi2==T,]
    mi.patients<-mi.patients[order(mi.patients[,ID.diagcodes], mi.patients[,dx.date], decreasing=F),]
    mi.patients<-mi.patients[duplicated(mi.patients[,ID.diagcodes])==F,]
    temp$mi<-ifelse(temp[,ID.patients] %in% mi.patients[,ID.diagcodes],T,F)
    #diagcodes<-diagcodes[(diagcodes$mi==F) & (diagcodes$mi2==F),]

    chf.codes<-c("428")
    chf.codes2<-c("I43", "I50",
				"P29.0", "I42.5", "I42.6", "I42.7", "I42.8", "I42.9",
				"I42.0", "I25.5", "I13.2", "I13.0", "I11.0", "I09.9")
    diagcodes$chf<-sapply(1:nrow(diagcodes), function (x) grepl(paste(chf.codes, collapse="|"), diagcodes[x,dx.diagcodes], ignore.case=T))
    diagcodes$chf2<-sapply(1:nrow(diagcodes), function (x) grepl(paste(chf.codes2, collapse="|"), diagcodes[x,dx.diagcodes2], ignore.case=T))
    chf.patients<-diagcodes[diagcodes$chf==T | diagcodes$chf2==T,]
    chf.patients<-chf.patients[order(chf.patients[,ID.diagcodes], chf.patients[,dx.date], decreasing=F),]
    all.chf.patients<-chf.patients[duplicated(chf.patients[,ID.diagcodes])==F,]
    temp$chf<-ifelse((temp[,ID.patients] %in% chf.patients[,ID.diagcodes]),T,F)
    #diagcodes<-diagcodes[(diagcodes$chf==F) & (diagcodes$chf2==F),]


    pvd.codes<-c("441","785.4", "443.9", "V43.4")
    pvd.codes2<-c("I70", "I71", "I73.8", "I79.2", "Z95.8", "Z95.9",
			"I73.1", "I73.9", "I77.1", "I79.0", "K55.1", "K55.8",
			"K55.9")
  diagcodes$pvd<-sapply(1:nrow(diagcodes), function (x) grepl(paste(pvd.codes, collapse="|"), diagcodes[x,dx.diagcodes], ignore.case=T))
    diagcodes$pvd2<-sapply(1:nrow(diagcodes), function (x) grepl(paste(pvd.codes2, collapse="|"), diagcodes[x,dx.diagcodes2], ignore.case=T))
    pvd.patients<-diagcodes[diagcodes$pvd==T | diagcodes$pvd2==T,]
    pvd.patients<-pvd.patients[order(pvd.patients[,ID.diagcodes], pvd.patients[,dx.date], decreasing=F),]
	all.pvd.patients<-pvd.patients[duplicated(pvd.patients[,ID.diagcodes])==F,]
    temp$pvd<-ifelse((temp[,ID.patients] %in% pvd.patients[,ID.diagcodes]),T,F)


    cd.codes<-c("430", "431", "432", "433", "434", "435", "436", "437", "438")
    cd.codes2<-c("G45", "G46", "H34.0", "I60", "I61", "I62", "I63", "I64", "I65", "I66", "I67", "I68", "I69")
	diagcodes$cd<-sapply(1:nrow(diagcodes), function (x) grepl(paste(cd.codes, collapse="|"), diagcodes[x,dx.diagcodes], ignore.case=T))
    diagcodes$cd2<-sapply(1:nrow(diagcodes), function (x) grepl(paste(cd.codes2, collapse="|"), diagcodes[x,dx.diagcodes2], ignore.case=T))
    cd.patients<-diagcodes[diagcodes$cd==T | diagcodes$cd2==T,]
    cd.patients<-cd.patients[order(cd.patients[,ID.diagcodes], cd.patients[,dx.date], decreasing=F),]
    cd.patients<-cd.patients[duplicated(cd.patients[,ID.diagcodes])==F,]
    temp$cd<-ifelse(temp[,ID.patients] %in% cd.patients[,ID.diagcodes],T,F)
    #diagcodes<-diagcodes[diagcodes$cd==F,]

    dementia.codes<-c("290")
    dementia.codes2<-c("G30",  "F05.1", "F00", "F01", "F02", "F03","G31.1")
    diagcodes$dementia<-sapply(1:nrow(diagcodes), function(x) grepl(paste(dementia.codes, collapse="|"), diagcodes[x,dx.diagcodes], ignore.case=T))
    diagcodes$dementia2<-sapply(1:nrow(diagcodes), function(x) grepl(paste(dementia.codes2, collapse="|"), diagcodes[x,dx.diagcodes2], ignore.case=T))
    dementia.patients<-diagcodes[diagcodes$dementia==T | diagcodes$dementia2==T,]
    dementia.patients<-dementia.patients[order(dementia.patients[,ID.diagcodes], dementia.patients[,dx.date], decreasing=F),]
    all.dementia.patients<-dementia.patients[duplicated(dementia.patients[,ID.diagcodes])==F,]
    temp$dementia<-ifelse((temp[,ID.patients] %in% dementia.patients[,ID.diagcodes]),T,F)
    #diagcodes<-diagcodes[diagcodes$dementia==F,]

    cpd.codes<-c("490", "491", "492", "493", "494", "495", "496", "497", "498", "499", "500", "501", "502", "503", "504", "505","506.4")
    cpd.codes2<-c("I27.8", "J40", "J41", "J42", "J43", "J44", "J45", "J46", "J47", "J60", "J61", "J62", "J63", "J64", "J65", "J66", "J67", "I27.9", "J68.4", "J70.1", "J70.3")
    diagcodes$cpd<-sapply(1:nrow(diagcodes), function (x) grepl(paste(cpd.codes, collapse="|"), diagcodes[x,dx.diagcodes], ignore.case=T))
    diagcodes$cpd2<-sapply(1:nrow(diagcodes), function (x) grepl(paste(cpd.codes2, collapse="|"), diagcodes[x,dx.diagcodes2], ignore.case=T))
    cpd.patients<-diagcodes[diagcodes$cpd==T | diagcodes$cpd2==T,]
    cpd.patients<-cpd.patients[order(cpd.patients[,ID.diagcodes], cpd.patients[,dx.date], decreasing=F),]
    all.cpd.patients<-cpd.patients[duplicated(cpd.patients[,ID.diagcodes])==F,]
    temp$cpd<-ifelse((temp[,ID.patients] %in% cpd.patients[,ID.diagcodes]) ,T,F)
    #diagcodes<-diagcodes[diagcodes$cpd==F,]


    rd.codes<-c("725","710.0", "710.1", "710.4", "714.0", "714.1", "714.2", "714.81")
    rd.codes2<-c("M05", "M06", "M32", "M33", "M34",
			"M31.5", "M35.1", "M35.3", "M36.0")
    diagcodes$rd<-sapply(1:nrow(diagcodes), function (x) grepl(paste(rd.codes, collapse="|"), diagcodes[x,dx.diagcodes], ignore.case=T))
    diagcodes$rd2<-sapply(1:nrow(diagcodes), function (x) grepl(paste(rd.codes2, collapse="|"), diagcodes[x,dx.diagcodes2], ignore.case=T))
    rd.patients<-diagcodes[diagcodes$rd==T | diagcodes$rd2==T,]
    rd.patients<-rd.patients[order(rd.patients[,ID.diagcodes], rd.patients[,dx.date], decreasing=F),]
    all.rd.patients<-rd.patients[duplicated(rd.patients[,ID.diagcodes])==F,]
    temp$rd<-ifelse((temp[,ID.patients] %in% rd.patients[,ID.diagcodes]),T,F)
    #diagcodes<-diagcodes[diagcodes$rd==F,]


    pud.codes<-c("531", "532", "533", "534")
    pud.codes2<-c("K25", "K26", "K27", "K28")
    diagcodes$pud<-sapply(1:nrow(diagcodes), function (x) grepl(paste(pud.codes, collapse="|"), diagcodes[x,dx.diagcodes], ignore.case=T))
    diagcodes$pud2<-sapply(1:nrow(diagcodes), function (x) grepl(paste(pud.codes2, collapse="|"), diagcodes[x,dx.diagcodes2], ignore.case=T))
    pud.patients<-diagcodes[diagcodes$pud==T | diagcodes$pud2==T,]
    pud.patients<-pud.patients[order(pud.patients[,ID.diagcodes], pud.patients[,dx.date], decreasing=F),]
    pud.patients<-pud.patients[duplicated(pud.patients[,ID.diagcodes])==F,]
    temp$pud<-ifelse(temp[,ID.patients] %in% pud.patients[,ID.diagcodes],T,F)
    #diagcodes<-diagcodes[diagcodes$pud==F,]

    mld.codes<-c("571.4","571.2", "571.5", "571.6")
    mld.codes2<-c("B18", "K73", "K74", "K76.8", "K70.1", "K70.3", "K71.5","Z94.4",
			"K76.0", "K76.2", "K76.3", "K76.4", "Z94.4", "K76.9",
			"K71.7", "K70.0", "K70.2", "K70.9", "K71.3", "K71.4")
    diagcodes$mld<-sapply(1:nrow(diagcodes), function (x) grepl(paste(mld.codes, collapse="|"), diagcodes[x,dx.diagcodes], ignore.case=T))
    diagcodes$mld2<-sapply(1:nrow(diagcodes), function (x) grepl(paste(mld.codes2, collapse="|"), diagcodes[x,dx.diagcodes2], ignore.case=T))
    mld.patients<-diagcodes[diagcodes$mld==T | diagcodes$mld2==T,]
    mld.patients<-mld.patients[order(mld.patients[,ID.diagcodes], mld.patients[,dx.date], decreasing=F),]
    all.mld.patients<-mld.patients[duplicated(mld.patients[,ID.diagcodes])==F,]
    temp$mld<-ifelse((temp[,ID.patients] %in% mld.patients[,ID.diagcodes]),T,F)
    #diagcodes<-diagcodes[diagcodes$mld==F,]


    diabetes.codes<-c("250.0", "250.1", "250.2", "250.3", "250.7",
						"^250$")  #250 is diabetes, but code doesn't pick up 250.  assume less severe unless specified, which will outweigh this category
	diabetes.codes2<-c("E10.0", "E10.1", "E10.6", "E10.8", "E10.9", "E11.0",
		"E11.1", "E11.6", "E11.8", "E11.9", "E12.0", "E12.1",
		"E12.6", "E12.8", "E12.9", "E13.0", "E13.1", "E13.6",
		"E13.8", "E13.9", "E14.0", "E14.1", "E14.6", "E14.8",
		"E14.9")
    diagcodes$diabetes<-sapply(1:nrow(diagcodes), function (x) grepl(paste(diabetes.codes, collapse="|"), diagcodes[x,dx.diagcodes], ignore.case=T))
    diagcodes$diabetes2<-sapply(1:nrow(diagcodes), function (x) grepl(paste(diabetes.codes2, collapse="|"), diagcodes[x,dx.diagcodes2], ignore.case=T))
    diabetes.patients<-diagcodes[diagcodes$diabetes==T | diagcodes$diabetes2==T,]
    diabetes.patients<-diabetes.patients[order(diabetes.patients[,ID.diagcodes], diabetes.patients[,dx.date], decreasing=F),]
    all.diabetes.patients<-diabetes.patients[duplicated(diabetes.patients[,ID.diagcodes])==F,]
    temp$diabetes<-ifelse((temp[,ID.patients] %in% diabetes.patients[,ID.diagcodes]) ,T,F)
    #diagcodes<-diagcodes[diagcodes$diabetes==F,]


    diabeteswc.codes<-c("250.4", "250.5", "250.6")
    diabeteswc.codes2<-c("E10.2", "E10.3", "E10.4", "E10.5", "E10.7", "E11.2", "E11.3", "E11.4", "E11.5",
                         "E11.7", "E12.2", "E12.3", "E12.4", "E12.5", "E12.7", "E13.2", "E13.3", "E13.4", "E13.5", "E13.7", "E14.2", "E14.3",
                         "E14.4", "E14.5", "E14.7")
    diagcodes$diabeteswc<-sapply(1:nrow(diagcodes), function (x) grepl(paste(diabeteswc.codes, collapse="|"), diagcodes[x,dx.diagcodes], ignore.case=T))
    diagcodes$diabeteswc2<-sapply(1:nrow(diagcodes), function (x) grepl(paste(diabeteswc.codes2, collapse="|"), diagcodes[x,dx.diagcodes2], ignore.case=T))
    diabeteswc.patients<-diagcodes[diagcodes$diabeteswc==T | diagcodes$diabeteswc2==T,]  #error here too
    diabeteswc.patients<-diabeteswc.patients[order(diabeteswc.patients[,ID.diagcodes], diabeteswc.patients[,dx.date], decreasing=F),]
    diabeteswc.patients<-diabeteswc.patients[duplicated(diabeteswc.patients[,ID.diagcodes])==F,]
    temp$diabeteswc<-ifelse(temp[,ID.patients] %in% diabeteswc.patients[,ID.diagcodes],T,F)
    #diagcodes<-diagcodes[diagcodes$diabeteswc==F,]

    hemiplegia.codes<-c("342", "344.1")
    hemiplegia.codes2<-c("G81", "G82", "G83.0", "G83.1", "G83.2", "G83.3", "G04.1", "G11.4", "G80.1", "G80.2", "G83.4", "G83.9")
    diagcodes$hemiplegia<-sapply(1:nrow(diagcodes), function (x) grepl(paste(hemiplegia.codes, collapse="|"), diagcodes[x,dx.diagcodes], ignore.case=T))
    diagcodes$hemiplegia2<-sapply(1:nrow(diagcodes), function (x) grepl(paste(hemiplegia.codes2, collapse="|"), diagcodes[x,dx.diagcodes2], ignore.case=T))
    hemiplegia.patients<-diagcodes[diagcodes$hemiplegia==T | diagcodes$hemiplegia2==T,]
    hemiplegia.patients<-hemiplegia.patients[order(hemiplegia.patients[,ID.diagcodes], hemiplegia.patients[,dx.date], decreasing=F),]
	all.hemiplegia.patients<-hemiplegia.patients[duplicated(hemiplegia.patients[,ID.diagcodes])==F,]
    temp$hemiplegia<-ifelse(temp[,ID.patients] %in% hemiplegia.patients[,ID.diagcodes],T,F)
    #diagcodes<-diagcodes[diagcodes$hemiplegia==F,]


    renal.codes<-c("582", "585", "586", "588", "583.0", "583.1", "583.2", "583.3", "583.4", "583.5", "583.6", "583.7")
    renal.codes2<-c("I13.1", "N18", "N19", "Z49.0", "Z49.1", "Z49.2", "I12.0", "N03.2", "N03.3", "N03.4", "N03.5", "N03.6", "N03.7", "N05.2",
              "N05.3", "N05.4", "N05.6", "N05.7",  "N25.0", "Z94.0", "Z99.2")
    diagcodes$renal<-sapply(1:nrow(diagcodes), function (x) grepl(paste(renal.codes, collapse="|"), diagcodes[x,dx.diagcodes], ignore.case=T))
    diagcodes$renal2<-sapply(1:nrow(diagcodes), function (x) grepl(paste(renal.codes2, collapse="|"), diagcodes[x,dx.diagcodes2], ignore.case=T))
    renal.patients<-diagcodes[diagcodes$renal==T | diagcodes$renal2==T,]
    renal.patients<-renal.patients[order(renal.patients[,ID.diagcodes], renal.patients[,dx.date], decreasing=F),]
    all.renal.patients<-renal.patients[duplicated(renal.patients[,ID.diagcodes])==F,]
     temp$renal<-ifelse(temp[,ID.patients] %in% renal.patients[,ID.diagcodes],T,F)
    #diagcodes<-diagcodes[diagcodes$renal==F,]


    malignancy.codes<-c("140", "141", "142", "143", "144", "145", "146", "147", "148", "149", "150",
                        "151", "152", "153", "154", "155", "156", "157", "158", "159", "160", "161",
                        "162", "163", "164", "165", "166", "167", "168", "169", "170", "171", "172",
                        "174", "175", "176", "177", "178", "179", "180", "181", "182", "183", "184",
                        "185", "186", "187", "188", "189", "190", "191", "192", "193", "194", "195.0",
                        "195.1", "195.2", "195.3", "195.4", "195.5", "195.6", "195.7", "195.8", "200",
                        "201", "202", "203", "204", "205", "206", "207", "208")
    malignancy.codes2<-c("C00", "C01", "C02", "C03", "C04", "C05", "C06", "C07", "C08", "C09", "C10",
                         "C11", "C12", "C13", "C14", "C15", "C16", "C17", "C18", "C19", "C20", "C21",
                         "C22", "C23", "C24", "C25", "C26", "C30", "C31", "C32", "C33", "C34", "C37",
                         "C38", "C39", "C40", "C41", "C43", "C45", "C46", "C47", "C48", "C49", "C50",
                         "C51", "C52", "C53", "C54", "C55", "C56", "C57", "C58", "C60", "C61", "C62",
                         "C63", "C64", "C65", "C66", "C67", "C68", "C69", "C70", "C71", "C72", "C73",
                         "C74", "C75", "C76", "C81", "C82", "C83", "C84", "C85", "C88", "C90", "C91",
                         "C92", "C93", "C94", "C95", "C96", "C97")
    diagcodes$malignancy<-sapply(1:nrow(diagcodes), function (x) grepl(paste(malignancy.codes, collapse="|"), diagcodes[x,dx.diagcodes], ignore.case=T))
    diagcodes$malignancy2<-sapply(1:nrow(diagcodes), function (x) grepl(paste(malignancy.codes2, collapse="|"), diagcodes[x,dx.diagcodes2], ignore.case=T))
    malignancy.patients<-diagcodes[diagcodes$malignancy==T | diagcodes$malignancy2==T,]
    malignancy.patients<-malignancy.patients[order(malignancy.patients[,ID.diagcodes], malignancy.patients[,dx.date], decreasing=F),]
    malignancy.patients<-malignancy.patients[duplicated(malignancy.patients[,ID.diagcodes])==F,]
    temp$malignancy<-ifelse(temp[,ID.patients] %in% malignancy.patients[,ID.diagcodes],T,F)
    #diagcodes<-diagcodes[diagcodes$malignancy==F,]

    liver.codes<-c("456.2",
			"456.0", "456.1", "572.2", "572.3", "572.4", "572.5",
			"572.6", "572.7", "572.8")
    liver.codes2<-c("I85.0", "I85.9", "I98.2", "K70.4", "K71.1", "K72.1", "K72.9",
				"I86.4", "K76.5", "K76.6", "K76.7")
    diagcodes$liver<-sapply(1:nrow(diagcodes), function (x) grepl(paste(liver.codes, collapse="|"), diagcodes[x,dx.diagcodes], ignore.case=T))
    diagcodes$liver2<-sapply(1:nrow(diagcodes), function (x) grepl(paste(liver.codes2, collapse="|"), diagcodes[x,dx.diagcodes2], ignore.case=T))
    liver.patients<-diagcodes[diagcodes$liver==T | diagcodes$liver2==T,]
    liver.patients<-liver.patients[order(liver.patients[,ID.diagcodes], liver.patients[,dx.date], decreasing=F),]
    all.liver.patients<-liver.patients[duplicated(liver.patients[,ID.diagcodes])==F,]
    temp$liver<-ifelse((temp[,ID.patients] %in% liver.patients[,ID.diagcodes]),T,F)
    #diagcodes<-diagcodes[diagcodes$liver==F,]

    tumor.codes<-c("196", "197", "198", "199.0", "199.1")
    tumor.codes2<-c("C77", "C78", "C79", "C80")
    diagcodes$tumor<-sapply(1:nrow(diagcodes), function (x) grepl(paste(tumor.codes, collapse="|"), diagcodes[x,dx.diagcodes], ignore.case=T))
    diagcodes$tumor2<-sapply(1:nrow(diagcodes), function (x) grepl(paste(tumor.codes2, collapse="|"), diagcodes[x,dx.diagcodes2], ignore.case=T))
    tumor.patients<-diagcodes[diagcodes$tumor==T | diagcodes$tumor2==T,]
    tumor.patients<-tumor.patients[order(tumor.patients[,ID.diagcodes], tumor.patients[,dx.date], decreasing=F),]
    tumor.patients<-tumor.patients[duplicated(tumor.patients[,ID.diagcodes])==F,]
    temp$tumor<-ifelse(temp[,ID.patients] %in% tumor.patients[,ID.diagcodes],T,F)
    #diagcodes<-diagcodes[diagcodes$tumor==F,]

    HIV.codes<-c("042", "043", "044")
    HIV.codes2<-c("B20", "B21", "B22", "B24")
    diagcodes$HIV<-sapply(1:nrow(diagcodes), function (x) grepl(paste(HIV.codes, collapse="|"), diagcodes[x,dx.diagcodes], ignore.case=T))
    diagcodes$HIV2<-sapply(1:nrow(diagcodes), function (x) grepl(paste(HIV.codes2, collapse="|"), diagcodes[x,dx.diagcodes2], ignore.case=T))
    HIV.patients<-diagcodes[diagcodes$HIV==T | diagcodes$HIV2==T,]
    HIV.patients<-HIV.patients[order(HIV.patients[,ID.diagcodes], HIV.patients[,dx.date], decreasing=F),]
    HIV.patients<-HIV.patients[duplicated(HIV.patients[,ID.diagcodes])==F,]
    temp$HIV<-ifelse(temp[,ID.patients] %in% HIV.patients[,ID.diagcodes],T,F)
    #diagcodes<-diagcodes[diagcodes$HIV==F,]
  }
}
  if (weights=="original"){
    calc.sum<-0
	liver.not.before<-0
	tumor.not.before<-0
	diab.not.before<-0
    i = NULL
    for (i in 1:nrow(temp)){
      ## Get all date parameters
      if(!(st.date=="1800-01-01")){
        if(!st.date %in% names(temp))
          {hold.start.date<-as.Date(st.date)
          }else{hold.start.date<-temp[i,st.date]}

      }
      if(st.date=="1800-01-01"){
        ## If the start date is not given by user, use the oldest start date possible
        hold.start.date<-as.Date(st.date)
      }
      if(!(end.date=="3000-01-01")){
        if(!end.date %in% names(temp))
        {hold.end.date<-as.Date(end.date)
        }else{hold.end.date<-temp[i,end.date]}
      }
      if(end.date=="3000-01-01"){
        ## If the end date is not given by user, use the furthest end date possible
        hold.end.date<-as.Date(end.date)
      }
      ## Put the ID of the patient in a holding variable
      hold.id <- temp[i, ID.patients]
		calc.sum <- 0
	  	liver.not.before<-0
		tumor.not.before<-0
		diab.not.before<-0
      ## If the patient has had an MI diagnosis code
      if(temp$mi[i]==T){
        ## Get the diagnosis code for that patient
        hold.mi<-mi.patients[mi.patients[,ID.diagcodes]==hold.id,]
        ## Make sure R didn't add extra rows
        hold.mi<-hold.mi[!is.na(hold.mi[,ID.diagcodes]),]
        ## Put the diagnosis date into a holding variable
        hold.mi.date<-hold.mi[1,dx.date]
        ## If the diagnosis date is in between the specified date range, then add to the CCI
        if((hold.mi.date <= hold.end.date) & (hold.mi.date >= hold.start.date)){
          calc.sum <- calc.sum+1
        }
        ## If the diagnosis date is outside of the specified date range, then do nothing
        else{
          calc.sum <- calc.sum
        }
      }
      if(temp$chf[i]==T){
        hold.chf<-all.chf.patients[all.chf.patients[,ID.diagcodes]==hold.id,]
        hold.chf<-hold.chf[!is.na(hold.chf[,ID.diagcodes]),]
        hold.chf.date<-hold.chf[,dx.date]
        if((hold.chf.date <= hold.end.date) & (hold.chf.date >= hold.start.date)){
          calc.sum <- calc.sum+1
        }
        else{
          calc.sum <- calc.sum
        }
      }
      if(temp$pvd[i]==T){
        hold.pvd<-all.pvd.patients[all.pvd.patients[,ID.diagcodes]==hold.id,]
        hold.pvd<-hold.pvd[!is.na(hold.pvd[,ID.diagcodes]),]
        hold.pvd.date<-hold.pvd[,dx.date]
        if((hold.pvd.date <= hold.end.date) & (hold.pvd.date >= hold.start.date)){
          calc.sum <- calc.sum+1
        }
        else{
          calc.sum <- calc.sum
        }
      }
      if(temp$cd[i]==T){
        hold.cd<-cd.patients[cd.patients[,ID.diagcodes]==hold.id,]
        hold.cd<-hold.cd[!is.na(hold.cd[,ID.diagcodes]),]
        hold.cd.date<-hold.cd[,dx.date]
        if((hold.cd.date <= hold.end.date) & (hold.cd.date >= hold.start.date)){
          calc.sum <- calc.sum+1
        }
        else{
          calc.sum <- calc.sum
        }
      }
      if(temp$dementia[i]==T){
        hold.dementia<-all.dementia.patients[all.dementia.patients[,ID.diagcodes]==hold.id,]
        hold.dementia<-hold.dementia[!is.na(hold.dementia[,ID.diagcodes]),]
        hold.dementia.date<-hold.dementia[,dx.date]
        if((hold.dementia.date <= hold.end.date) & (hold.dementia.date >= hold.start.date)){
          calc.sum <- calc.sum+1
        }
        else{
          calc.sum <- calc.sum
        }
      }
      if(temp$cpd[i]==T){
        hold.cpd<-all.cpd.patients[all.cpd.patients[,ID.diagcodes]==hold.id,]
        hold.cpd<-hold.cpd[!is.na(hold.cpd[,ID.diagcodes]),]
        hold.cpd.date<-hold.cpd[,dx.date]
        if((hold.cpd.date <= hold.end.date) & (hold.cpd.date >= hold.start.date)){
          calc.sum <- calc.sum+1
        }
        else{
          calc.sum <- calc.sum
        }
      }
      if(temp$rd[i]==T){
        hold.rd<-all.rd.patients[all.rd.patients[,ID.diagcodes]==hold.id,]
        hold.rd<-hold.rd[!is.na(hold.rd[,ID.diagcodes]),]
        hold.rd.date<-hold.rd[,dx.date]
        if((hold.rd.date <= hold.end.date) & (hold.rd.date >= hold.start.date)){
          calc.sum <- calc.sum+1
        }
        else{
          calc.sum <- calc.sum
        }
      }
      if(temp$pud[i]==T){
        hold.pud<-pud.patients[pud.patients[,ID.diagcodes]==hold.id,]
        hold.pud<-hold.pud[!is.na(hold.pud[,ID.diagcodes]),]
        hold.pud.date<-hold.pud[,dx.date]
        if((hold.pud.date <= hold.end.date) & (hold.pud.date >= hold.start.date)){
          calc.sum <- calc.sum+1
        }
        else{
          calc.sum <- calc.sum
        }
      }
	  #SEVERE OVER MILD
	    if(temp$liver[i]==T){
        hold.liver<-all.liver.patients[all.liver.patients[,ID.diagcodes]==hold.id,]
        hold.liver<-hold.liver[!is.na(hold.liver[,ID.diagcodes]),]
        hold.liver.date<-hold.liver[,dx.date]
        if((hold.liver.date <= hold.end.date) & (hold.liver.date >= hold.start.date)){
          calc.sum <- calc.sum+3
		  liver.not.before<-liver.not.before
        }
        else{
          calc.sum <- calc.sum
		  liver.not.before<-liver.not.before+1
        }
      }

      if((temp$mld[i]==T & temp$liver[i]==F)|
		(temp$mld[i]==T & liver.not.before==1)){  #if severe
        hold.mld<-all.mld.patients[all.mld.patients[,ID.diagcodes]==hold.id,]
        hold.mld<-hold.mld[!is.na(hold.mld[,ID.diagcodes]),]
        hold.mld.date<-hold.mld[,dx.date]
        if((hold.mld.date <= hold.end.date) & (hold.mld.date >= hold.start.date)){  #mutually exclusive with severe
          calc.sum <- calc.sum+1
        }
        else{
          calc.sum <- calc.sum
        }
      }
	  #DIABETES WITH WC OVER DIABET WO
      if(temp$diabeteswc[i]==T){
        hold.diabeteswc<-diabeteswc.patients[diabeteswc.patients[,ID.diagcodes]==hold.id,]
        hold.diabeteswc<-hold.diabeteswc[!is.na(hold.diabeteswc[,ID.diagcodes]),]
        hold.diabeteswc.date<-hold.diabeteswc[,dx.date]
        if((hold.diabeteswc.date <= hold.end.date) & (hold.diabeteswc.date >= hold.start.date)){
          calc.sum <- calc.sum+2
		   diab.not.before<-diab.not.before
        }
        else{
          calc.sum <- calc.sum
		  diab.not.before<-diab.not.before+1
        }
      }
	  #if this person has diab without complication only
      if((temp$diabetes[i]==T & temp$diabeteswc[i]==F)|
		(temp$diabetes[i]==T & diab.not.before==1)){
        hold.diabetes<-all.diabetes.patients[all.diabetes.patients[,ID.diagcodes]==hold.id,]
        hold.diabetes<-hold.diabetes[!is.na(hold.diabetes[,ID.diagcodes]),]
        hold.diabetes.date<-hold.diabetes[,dx.date]
        if((hold.diabetes.date <= hold.end.date) & (hold.diabetes.date >= hold.start.date)){
          calc.sum <- calc.sum+1
        }
        else{
          calc.sum <- calc.sum
        }
      }
      if(temp$hemiplegia[i]==T){
        hold.hemiplegia<-all.hemiplegia.patients[all.hemiplegia.patients[,ID.diagcodes]==hold.id,]
        hold.hemiplegia<-hold.hemiplegia[!is.na(hold.hemiplegia[,ID.diagcodes]),]
        hold.hemiplegia.date<-hold.hemiplegia[,dx.date]
        if((hold.hemiplegia.date <= hold.end.date) & (hold.hemiplegia.date >= hold.start.date)){
          calc.sum <- calc.sum+2
        }
        else{
          calc.sum <- calc.sum
        }
      }
      if(temp$renal[i]==T){
        hold.renal<-all.renal.patients[all.renal.patients[,ID.diagcodes]==hold.id,]
        hold.renal<-hold.renal[!is.na(hold.renal[,ID.diagcodes]),]
        hold.renal.date<-hold.renal[,dx.date]
        if((hold.renal.date <= hold.end.date) & (hold.renal.date >= hold.start.date)){
          calc.sum <- calc.sum+2
        }
        else{
          calc.sum <- calc.sum
        }
      }

	   if(temp$tumor[i]==T){
        hold.tumor<-tumor.patients[tumor.patients[,ID.diagcodes]==hold.id,]
        hold.tumor<-hold.tumor[!is.na(hold.tumor[,ID.diagcodes]),]
        hold.tumor.date<-hold.tumor[,dx.date]
        if((hold.tumor.date <= hold.end.date) & (hold.tumor.date >= hold.start.date)){
          calc.sum <- calc.sum+6
		   tumor.not.before<-tumor.not.before
        }
        else{
          calc.sum <- calc.sum
		  tumor.not.before<-tumor.not.before+1
        }
      }
        if((temp$malignancy[i]==T & temp$tumor[i]==F)|
			 (temp$malignancy[i]==T & tumor.not.before==1)){
        hold.malignancy<-malignancy.patients[malignancy.patients[,ID.diagcodes]==hold.id,]
        hold.malignancy<-hold.malignancy[!is.na(hold.malignancy[,ID.diagcodes]),]
        hold.malignancy.date<-hold.malignancy[,dx.date]
        if((hold.malignancy.date <= hold.end.date) & (hold.malignancy.date >= hold.start.date)){
          calc.sum <- calc.sum+2
        }
        else{
          calc.sum <- calc.sum
        }
      }

      if (temp$HIV[i]==T){
        hold.HIV<-HIV.patients[HIV.patients[,ID.diagcodes]==hold.id,]
        hold.HIV<-hold.HIV[!is.na(hold.HIV[,ID.diagcodes]),]
        hold.HIV.date<-hold.HIV[,dx.date]
        if((hold.HIV.date <= hold.end.date) & (hold.HIV.date >= hold.start.date)){
          calc.sum <- calc.sum+6
        }
        else{
          calc.sum <- calc.sum
        }
      }
      patients$CCIo[i]<-calc.sum
    }
	return(patients)
	}
  if(weights=="quan"){
	# mutually exclusive categories include mild liver disease and moderate or severe liver disease
	#metastatic solid tumore and any malignancy
    calc.sum<-0
	liver.not.before<-0
	tumor.not.before<-0
    i = NULL
    for (i in 1:nrow(temp)){
      ## Get all date parameters
      if(!(st.date=="1800-01-01")){
        if(!st.date %in% names(temp))
        {hold.start.date<-as.Date(st.date)
        }else{hold.start.date<-temp[i,st.date]}

      }
      if(st.date=="1800-01-01"){
        ## If the start date is not given by user, use the oldest start date possible
        hold.start.date<-as.Date(st.date)
      }
      if(!(end.date=="3000-01-01")){
        if(!end.date %in% names(temp))
        {hold.end.date<-as.Date(end.date)
        }else{hold.end.date<-temp[i,end.date]}
      }
      if(end.date=="3000-01-01"){
        ## If the end date is not given by user, use the furthest end date possible
        hold.end.date<-as.Date(end.date)
      }
      hold.id <- temp[i, ID.patients]
      calc.sum <- 0
      ########
	  #MI = 0#
	  ########
	  #if(temp$mi[i]==T){
      #  hold.mi<-mi.patients[mi.patients[,ID.diagcodes]==hold.id,]
      #  hold.mi<-hold.mi[!is.na(hold.mi[,ID.patients]),]
      #  hold.mi.date<-hold.mi[1,dx.date]
      #  if((hold.mi.date <= hold.end.date) & (hold.mi.date >= hold.start.date)){
      #    calc.sum <- calc.sum
       # }
       # else{
       #   calc.sum <- calc.sum
       # }
      #}
	  #####
	  #CHF#
	  #####
      if(temp$chf[i]==T){
        hold.chf<-all.chf.patients[all.chf.patients[,ID.diagcodes]==hold.id,]
        hold.chf<-hold.chf[!is.na(hold.chf[,ID.diagcodes]),]
        hold.chf.date<-hold.chf[,dx.date]
        if((hold.chf.date <= hold.end.date) & (hold.chf.date >= hold.start.date)){
          calc.sum <- calc.sum+2
        }
        else{
          calc.sum <- calc.sum
        }
      }
     #if(temp$pvd[i]==T){
     #  hold.pvd<-all.pvd.patients[all.pvd.patients[,ID.diagcodes]==hold.id,]
     #  hold.pvd<-hold.pvd[!is.na(hold.pvd[,ID.patients]),]
     #  hold.pvd.date<-hold.pvd[,dx.date]
     #  if((hold.pvd.date <= hold.end.date) & (hold.pvd.date >= hold.start.date)){
     #    calc.sum <- calc.sum
     #  }
     #  else{
     #    calc.sum <- calc.sum
     #  }
     #}
     #if(temp$cd[i]==T){
     #  hold.cd<-cd.patients[cd.patients[,ID.diagcodes]==hold.id,]
     #  hold.cd<-hold.cd[!is.na(hold.cd[,ID.patients]),]
     #  hold.cd.date<-hold.cd[,dx.date]
     #  if((hold.cd.date <= hold.end.date) & (hold.cd.date >= hold.start.date)){
     #    calc.sum <- calc.sum
     #  }
     #  else{
     #    calc.sum <- calc.sum
     #  }
     #}
      if(temp$dementia[i]==T){
        hold.dementia<-all.dementia.patients[all.dementia.patients[,ID.diagcodes]==hold.id,]
        hold.dementia<-hold.dementia[!is.na(hold.dementia[,ID.diagcodes]),]
        hold.dementia.date<-hold.dementia[,dx.date]
        if((hold.dementia.date <= hold.end.date) & (hold.dementia.date >= hold.start.date)){
          calc.sum <- calc.sum+2
        }
        else{
          calc.sum <- calc.sum
        }
      }
	  #######
	  #CPD 1#
	  #######
      if(temp$cpd[i]==T){
        hold.cpd<-all.cpd.patients[all.cpd.patients[,ID.diagcodes]==hold.id,]
        hold.cpd<-hold.cpd[!is.na(hold.cpd[,ID.diagcodes]),]
        hold.cpd.date<-hold.cpd[,dx.date]
        if((hold.cpd.date <= hold.end.date) & (hold.cpd.date >= hold.start.date)){
          calc.sum <- calc.sum+1
        }
        else{
          calc.sum <- calc.sum
        }
      }
	  #######
	  #RD 1#
	  ######
      if(temp$rd[i]==T){
        hold.rd<-all.rd.patients[all.rd.patients[,ID.diagcodes]==hold.id,]
        hold.rd<-hold.rd[!is.na(hold.rd[,ID.diagcodes]),]
        hold.rd.date<-hold.rd[,dx.date]
        if((hold.rd.date <= hold.end.date) & (hold.rd.date >= hold.start.date)){
          calc.sum <- calc.sum+1
        }
        else{
          calc.sum <- calc.sum
        }
      }
     #if(temp$pud[i]==T){
     #  hold.pud<-pud.patients[pud.patients[,ID.diagcodes]==hold.id,]
     #  hold.pud<-hold.pud[!is.na(hold.pud[,ID.patients]),]
     #  hold.pud.date<-hold.pud[,dx.date]
     #  if((hold.pud.date <= hold.end.date) & (hold.pud.date >= hold.start.date)){
     #    calc.sum <- calc.sum
     #  }
     #  else{
     #    calc.sum <- calc.sum
     # }
     #}
	  ######################################
	  #Severe liver mutually exclusive mild#
	  ######################################
	    if(temp$liver[i]==T){
        hold.liver<-all.liver.patients[all.liver.patients[,ID.diagcodes]==hold.id,]
        hold.liver<-hold.liver[!is.na(hold.liver[,ID.diagcodes]),]
        hold.liver.date<-hold.liver[,dx.date]
        if((hold.liver.date <= hold.end.date) & (hold.liver.date >= hold.start.date)){
          calc.sum <- calc.sum+4
		  liver.not.before<-liver.not.before
        }
        else{
          calc.sum <- calc.sum
		  liver.not.before<-liver.not.before+1
        }
      }

	 ########
	 #MLD 2#
	 #######
      if((temp$mld[i]==T & temp$liver[i]==F) |
			(temp$mld[i]==T & liver.not.before==1)){  #if
        hold.mld<-all.mld.patients[all.mld.patients[,ID.diagcodes]==hold.id,]
        hold.mld<-hold.mld[!is.na(hold.mld[,ID.diagcodes]),]
        hold.mld.date<-hold.mld[,dx.date]
        if((hold.mld.date <= hold.end.date) & (hold.mld.date >= hold.start.date)){
          calc.sum <- calc.sum+2
        }
        else{
          calc.sum <- calc.sum
        }
      }
	  #######
	  #DWC=1#
	  #######
      if(temp$diabeteswc[i]==T){
        hold.diabeteswc<-diabeteswc.patients[diabeteswc.patients[,ID.diagcodes]==hold.id,]
        hold.diabeteswc<-hold.diabeteswc[!is.na(hold.diabeteswc[,ID.diagcodes]),]
        hold.diabeteswc.date<-hold.diabeteswc[,dx.date]
        if((hold.diabeteswc.date <= hold.end.date) & (hold.diabeteswc.date >= hold.start.date)){
          calc.sum <- calc.sum+1
        }
        else{
          calc.sum <- calc.sum
        }
      }
     #if(temp$diabetes[i]==T & temp$diabeteswc[i]==F){
     #  hold.diabetes<-all.diabetes.patients[all.diabetes.patients[,ID.diagcodes]==hold.id,]
     #  hold.diabetes<-hold.diabetes[!is.na(hold.diabetes[,ID.patients]),]
     #  hold.diabetes.date<-hold.diabetes[,dx.date]
     #  if((hold.diabetes.date <= hold.end.date) & (hold.diabetes.date >= hold.start.date)){
      #   calc.sum <- calc.sum+0
      # }
      # else{
      #   calc.sum <- calc.sum
      # }
     #}
	 #######
	 #HEM 2#
	 #######
      if(temp$hemiplegia[i]==T){
        hold.hemiplegia<-all.hemiplegia.patients[all.hemiplegia.patients[,ID.diagcodes]==hold.id,]
        hold.hemiplegia<-hold.hemiplegia[!is.na(hold.hemiplegia[,ID.diagcodes]),]
        hold.hemiplegia.date<-hold.hemiplegia[,dx.date]
        if((hold.hemiplegia.date <= hold.end.date) & (hold.hemiplegia.date >= hold.start.date)){
          calc.sum <- calc.sum+2
        }
        else{
          calc.sum <- calc.sum
        }
      }


	#########
	#RENAL #
	#########
      if(temp$renal[i]==T){
        hold.renal<-all.renal.patients[all.renal.patients[,ID.diagcodes]==hold.id,]
        hold.renal<-hold.renal[!is.na(hold.renal[,ID.diagcodes]),]
        hold.renal.date<-hold.renal[,dx.date]
        if((hold.renal.date <= hold.end.date) & (hold.renal.date >= hold.start.date)){
          calc.sum <- calc.sum+1
        }
        else{
          calc.sum <- calc.sum
        }
      }

	#################
	#METASTATIC TUMOR - Mutually exclusive with Malignancy
	   if(temp$tumor[i]==T){
        hold.tumor<-tumor.patients[tumor.patients[,ID.diagcodes]==hold.id,]
        hold.tumor<-hold.tumor[!is.na(hold.tumor[,ID.diagcodes]),]
        hold.tumor.date<-hold.tumor[,dx.date]
        if((hold.tumor.date <= hold.end.date) & (hold.tumor.date >= hold.start.date)){
          calc.sum <- calc.sum+6
		  tumor.not.before<-tumor.not.before
        }
        else{
          calc.sum <- calc.sum
		  tumor.not.before<-tumor.not.before+1
        }
      }

	  #########
	  #MALIG 2#
      if((temp$malignancy[i]==T & temp$tumor[i]==F)|
		 	 (temp$malignancy[i]==T & tumor.not.before==1)){
        hold.malignancy<-malignancy.patients[malignancy.patients[,ID.diagcodes]==hold.id,]
        hold.malignancy<-hold.malignancy[!is.na(hold.malignancy[,ID.diagcodes]),]
        hold.malignancy.date<-hold.malignancy[,dx.date]
        if((hold.malignancy.date <= hold.end.date) & (hold.malignancy.date >= hold.start.date)){
          calc.sum <- calc.sum+2
        }
        else{
          calc.sum <- calc.sum
        }
      }

      if (temp$HIV[i]==T){
        hold.HIV<-HIV.patients[HIV.patients[,ID.diagcodes]==hold.id,]
        hold.HIV<-hold.HIV[!is.na(hold.HIV[,ID.diagcodes]),]
        hold.HIV.date<-hold.HIV[,dx.date]
        if((hold.HIV.date <= hold.end.date) & (hold.HIV.date >= hold.start.date)){
          calc.sum <- calc.sum+4
        }
        else{
          calc.sum <- calc.sum
        }
      }
      patients$CCIq[i]<-calc.sum
    }
	return(patients)
	}
	##############
	#SCHNEEWEISS###
	###############
 if(weights=="schneeweiss"){
  calc.sum<-0
  	liver.not.before<-0
	tumor.not.before<-0
	diab.not.before<-0
    i = NULL
    for (i in 1:nrow(temp)){
      ## Get all date parameters
      if(!(st.date=="1800-01-01")){
        if(!st.date %in% names(temp))
          {hold.start.date<-as.Date(st.date)
          }else{hold.start.date<-temp[i,st.date]}

      }
      if(st.date=="1800-01-01"){
        ## If the start date is not given by user, use the oldest start date possible
        hold.start.date<-as.Date(st.date)
      }
      if(!(end.date=="3000-01-01")){
        if(!end.date %in% names(temp))
        {hold.end.date<-as.Date(end.date)
        }else{hold.end.date<-temp[i,end.date]}
      }
      if(end.date=="3000-01-01"){
        ## If the end date is not given by user, use the furthest end date possible
        hold.end.date<-as.Date(end.date)
      }
      ## Put the ID of the patient in a holding variable
      hold.id <- temp[i, ID.patients]
      calc.sum <- 0
      ## If the patient has had an MI diagnosis codechafasdfsafdsafdsa
      if(temp$mi[i]==T){
        ## Get the diagnosis code for that patient
        hold.mi<-mi.patients[mi.patients[,ID.diagcodes]==hold.id,]
        ## Make sure R didn't add extra rows
        hold.mi<-hold.mi[!is.na(hold.mi[,ID.diagcodes]),]
        ## Put the diagnosis date into a holding variable
        hold.mi.date<-hold.mi[1,dx.date]
        ## If the diagnosis date is in between the specified date range, then add to the CCI
        if((hold.mi.date <= hold.end.date) & (hold.mi.date >= hold.start.date)){
          calc.sum <- calc.sum+1
        }
        ## If the diagnosis date is outside of the specified date range, then do nothing
        else{
          calc.sum <- calc.sum
        }
      }
      if(temp$chf[i]==T){
        hold.chf<-all.chf.patients[all.chf.patients[,ID.diagcodes]==hold.id,]
        hold.chf<-hold.chf[!is.na(hold.chf[,ID.diagcodes]),]
        hold.chf.date<-hold.chf[,dx.date]
        if((hold.chf.date <= hold.end.date) & (hold.chf.date >= hold.start.date)){
          calc.sum <- calc.sum+2
        }
        else{
          calc.sum <- calc.sum
        }
      }
        if(temp$pvd[i]==T){
        hold.pvd<-all.pvd.patients[all.pvd.patients[,ID.diagcodes]==hold.id,]
        hold.pvd<-hold.pvd[!is.na(hold.pvd[,ID.diagcodes]),]
        hold.pvd.date<-hold.pvd[,dx.date]
        if((hold.pvd.date <= hold.end.date) & (hold.pvd.date >= hold.start.date)){
          calc.sum <- calc.sum+1
        }
        else{
          calc.sum <- calc.sum
        }
      }
      if(temp$cd[i]==T){
        hold.cd<-cd.patients[cd.patients[,ID.diagcodes]==hold.id,]
        hold.cd<-hold.cd[!is.na(hold.cd[,ID.diagcodes]),]
        hold.cd.date<-hold.cd[,dx.date]
        if((hold.cd.date <= hold.end.date) & (hold.cd.date >= hold.start.date)){
          calc.sum <- calc.sum+1
        }
        else{
          calc.sum <- calc.sum
        }
      }
      if(temp$dementia[i]==T){
        hold.dementia<-all.dementia.patients[all.dementia.patients[,ID.diagcodes]==hold.id,]
        hold.dementia<-hold.dementia[!is.na(hold.dementia[,ID.diagcodes]),]
        hold.dementia.date<-hold.dementia[,dx.date]
        if((hold.dementia.date <= hold.end.date) & (hold.dementia.date >= hold.start.date)){
          calc.sum <- calc.sum+3
        }
        else{
          calc.sum <- calc.sum
        }
      }
      if(temp$cpd[i]==T){
        hold.cpd<-all.cpd.patients[all.cpd.patients[,ID.diagcodes]==hold.id,]
        hold.cpd<-hold.cpd[!is.na(hold.cpd[,ID.diagcodes]),]
        hold.cpd.date<-hold.cpd[,dx.date]
        if((hold.cpd.date <= hold.end.date) & (hold.cpd.date >= hold.start.date)){
          calc.sum <- calc.sum+2
        }
        else{
          calc.sum <- calc.sum
        }
      }
      #if(temp$rd[i]==T){
      #  hold.rd<-all.rd.patients[all.rd.patients[,ID.diagcodes]==hold.id,]
      #  hold.rd<-hold.rd[!is.na(hold.rd[,ID.patients]),]
      #  hold.rd.date<-hold.rd[,dx.date]
      #  if((hold.rd.date <= hold.end.date) & (hold.rd.date >= hold.start.date)){
      #    calc.sum <- calc.sum
      #  }
      #  else{
      #    calc.sum <- calc.sum
      #  }
      #}
      #if(temp$pud[i]==T){
      #  hold.pud<-pud.patients[pud.patients[,ID.diagcodes]==hold.id,]
      #  hold.pud<-hold.pud[!is.na(hold.pud[,ID.patients]),]
      #  hold.pud.date<-hold.pud[,dx.date]
      #  if((hold.pud.date <= hold.end.date) & (hold.pud.date >= hold.start.date)){
      #    calc.sum <- calc.sum
      #  }
      #  else{
      #    calc.sum <- calc.sum
      #  }
      #}
	  ####severe Here
	    if(temp$liver[i]==T){
        hold.liver<-all.liver.patients[all.liver.patients[,ID.diagcodes]==hold.id,]
        hold.liver<-hold.liver[!is.na(hold.liver[,ID.diagcodes]),]
        hold.liver.date<-hold.liver[,dx.date]
        if((hold.liver.date <= hold.end.date) & (hold.liver.date >= hold.start.date)){
          calc.sum <- calc.sum+4
		  liver.not.before<-liver.not.before
        }
        else{
          calc.sum <- calc.sum
		  liver.not.before<-liver.not.before+1
        }
      }

      if((temp$mld[i]==T & temp$liver[i]==F) |
		(temp$mld[i]==T & liver.not.before==1)){  #if
        hold.mld<-all.mld.patients[all.mld.patients[,ID.diagcodes]==hold.id,]
        hold.mld<-hold.mld[!is.na(hold.mld[,ID.diagcodes]),]
        hold.mld.date<-hold.mld[,dx.date]
        if((hold.mld.date <= hold.end.date) & (hold.mld.date >= hold.start.date)){  #mutually exclusive with severe
          calc.sum <- calc.sum+2
        }
        else{
          calc.sum <- calc.sum
        }
      }
      if(temp$diabeteswc[i]==T){
        hold.diabeteswc<-diabeteswc.patients[diabeteswc.patients[,ID.diagcodes]==hold.id,]
        hold.diabeteswc<-hold.diabeteswc[!is.na(hold.diabeteswc[,ID.diagcodes]),]
        hold.diabeteswc.date<-hold.diabeteswc[,dx.date]
        if((hold.diabeteswc.date <= hold.end.date) & (hold.diabeteswc.date >= hold.start.date)){
          calc.sum <- calc.sum+2
		   diab.not.before<- diab.not.before
        }
        else{
          calc.sum <- calc.sum
		  diab.not.before<- diab.not.before+1
        }
      }
      if((temp$diabetes[i]==T & temp$diabeteswc[i]==F)|
		(temp$diabetes[i]==T & diab.not.before==1)){
        hold.diabetes<-all.diabetes.patients[all.diabetes.patients[,ID.diagcodes]==hold.id,]
        hold.diabetes<-hold.diabetes[!is.na(hold.diabetes[,ID.diagcodes]),]
        hold.diabetes.date<-hold.diabetes[,dx.date]
        if((hold.diabetes.date <= hold.end.date) & (hold.diabetes.date >= hold.start.date)
			){  #mutually exclusive with diabeteswc
          calc.sum <- calc.sum+1
        }
        else{
          calc.sum <- calc.sum
        }
      }
      if(temp$hemiplegia[i]==T){
        hold.hemiplegia<-all.hemiplegia.patients[all.hemiplegia.patients[,ID.diagcodes]==hold.id,]
        hold.hemiplegia<-hold.hemiplegia[!is.na(hold.hemiplegia[,ID.diagcodes]),]
        hold.hemiplegia.date<-hold.hemiplegia[,dx.date]
        if((hold.hemiplegia.date <= hold.end.date) & (hold.hemiplegia.date >= hold.start.date)){
          calc.sum <- calc.sum+1
        }
        else{
          calc.sum <- calc.sum
        }
      }
      if(temp$renal[i]==T){
        hold.renal<-all.renal.patients[all.renal.patients[,ID.diagcodes]==hold.id,]
        hold.renal<-hold.renal[!is.na(hold.renal[,ID.diagcodes]),]
        hold.renal.date<-hold.renal[,dx.date]
        if((hold.renal.date <= hold.end.date) & (hold.renal.date >= hold.start.date)){
          calc.sum <- calc.sum+3
        }
        else{
          calc.sum <- calc.sum
        }
      }

	   if(temp$tumor[i]==T){
        hold.tumor<-tumor.patients[tumor.patients[,ID.diagcodes]==hold.id,]
        hold.tumor<-hold.tumor[!is.na(hold.tumor[,ID.diagcodes]),]
        hold.tumor.date<-hold.tumor[,dx.date]
        if((hold.tumor.date <= hold.end.date) & (hold.tumor.date >= hold.start.date)){
          calc.sum <- calc.sum+6
		  tumor.not.before<-tumor.not.before
        }
        else{
          calc.sum <- calc.sum
		  tumor.not.before<-tumor.not.before+1
        }
      }
        if((temp$malignancy[i]==T & temp$tumor[i]==F)|
			 (temp$malignancy[i]==T & tumor.not.before==1)){
        hold.malignancy<-malignancy.patients[malignancy.patients[,ID.diagcodes]==hold.id,]
        hold.malignancy<-hold.malignancy[!is.na(hold.malignancy[,ID.diagcodes]),]
        hold.malignancy.date<-hold.malignancy[,dx.date]
        if((hold.malignancy.date <= hold.end.date) & (hold.malignancy.date >= hold.start.date)){
          calc.sum <- calc.sum+2
        }
        else{
          calc.sum <- calc.sum
        }
      }


      if (temp$HIV[i]==T){
        hold.HIV<-HIV.patients[HIV.patients[,ID.diagcodes]==hold.id,]
        hold.HIV<-hold.HIV[!is.na(hold.HIV[,ID.diagcodes]),]
        hold.HIV.date<-hold.HIV[,dx.date]
        if((hold.HIV.date <= hold.end.date) & (hold.HIV.date >= hold.start.date)){
          calc.sum <- calc.sum+4
        }
        else{
          calc.sum <- calc.sum
        }
      }
      patients$CCIs[i]<-calc.sum
    }
	return(patients)
  }
}

