#' @title Patient Data Set to demonstrate CCI function
#'
#' @description A data from containing a artificial list of patients used to demonstrate the CCI function
#' @name patient
#' @keywords datasets
#' @docType data
#' @format A data frame with 20 rows and 7 columns
#' @keywords datasets
NULL
