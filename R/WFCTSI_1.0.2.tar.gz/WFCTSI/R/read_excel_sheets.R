#'Read Excel Spreadsheets
#'
#'@description Computes a modified version of the Charlson Comorbidity Index (CCI) that was adapted for use with administrative data (e.g. diagnoses codes from electronic health records).
#'By default, the function will calculate the score using the method described by Quan et.al.
#'by classifying and/or weighting comorbidities as defined by diagnosis codes (ICD9 and ICD10),
#'This function is optimized to integrate two data frames:
#'A set of patients with or without a defined start and stop date and a set of diagnosis codes that can be linked to the patient set by an identifier such as "MRN." The ICD file must contain separate columns for ICD9 and ICD10 codes and the corresponding date for each code.
#'The function searches for patients in the ICD data frame, indexes comorbidities that occur between the st.date and end.date, computes the CCI, and attaches the value to the patient data frame.
#'
#'
#'@param filename A filepath ending with excel file in ".xlxs" format.
#'@return Returns a list of excel spreadsheets
#'@author Kristin Lenoir \email{klenoir@wakehealth.edu}
#'@description uses "readxl" library to read excel spreadsheets
#'@keywords excel spreadsheet
#'@export

#Write function to read multiple sheets
read_excel_allsheets <- function(filename) {
  sheets <- readxl::excel_sheets(filename)
  x <-    lapply(sheets, function(X) readxl::read_excel(filename, sheet = X,
                                                        col_types ="text",  #import all as characters
                                                        col_names=T, #give it column names
                                                        na=c(""," ","NA"), #designate white space as na
                                                        trim_ws=T )) #trim extra spaces
  names(x) <- sheets
  x
}
