#'Glomular Filtration Rate Calculation
#'@description Calculates Glomular Filtration Rate (GFR) (mL/min/1.73 m2) from serum creatinine (mg/dL) using the CKD-Epi Equation.
#'@param patients A data frame containing encounter and demographic information
#'@param ID.patients A column name in patients identifying patient encounters (common value CSN)
#'@param gender A column name in patients with "M" or "Male" for male and all other values designated as female
#'@param race A column name in patients with "B" or "Black or African American" for Black and all other values designated as non-Black/African American
#'@param age A column in patients. Units must be years. Class of character or numeric
#'@param labs	A data frame containing creatinine lab information often by encounter
#'@param ID.labs A column name in labs identifying patient encounters (common value is CSN)
#'@param lab.name A column name in labs identifying laboratory test names. Can be defined as "none" if lab names do not exist
#'or if creatinine lab tests names include values other than "CREATININE", "CREATINE, SERUM", or "CREATININE LEVEL".
#'lab.name searches for the three aformentioned lab test names.
#'@param ord.value A column name in labs with plasma or serum creatinine values. Units must be mg/dL
#'@param result.date  A column name in labs with date and time of creatinine test. Class must be Date or Posix.
#'@return The patients data frame with creatinine and gfr values attached as columns.
#'"CREAT_VALUE": column of creatinine values (mg/dL) from labs data frame used for calculation.
#'"GFR": column of GFR values (mL/min/1.73m2.)
#'@details Patient and lab data frames are merged by matching encounter identifiers (common value of CSN) (ID.patients and ID.labs).
#'If multiple creatinine values exist for the same encounter, the most recent value is used. If a patient in the patients data frame
#'does not have a corresponding lab data frame encounter, the resulting GFR value is NA.
#'The CKD-Epi equation used for the GFR function is intended for use with a creatinine method that has calibration traceable
#'to an isotope dilution mass spectrometry (IDMS) reference measurement procedure.
#'@keywords gfr, Glomular Filtration Rate
#'
#'@author Kristin Lenoir \email{klenoir@wakehealth.edu}
#'@references Levey AS, Stevens LA, Schmid CH, Zhang YL, Castro AF, Feldman HI, et al. A new equation to estimate glomerular filtration rate. Ann Intern Med. 2009 May 5;150(9):604-12.
#'The National Kidney Foundation recommends using the CKD-EPI Creatinine Equation (2009) to estimate GFR.
#'@examples
#'#calculate gfr
#'gfrx #view patient data set
#'gfry #view lab value data set
#'
#'#format date
#'gfry$date<-as.Date(as.POSIXlt(gfry$RESULT_DATE_TIME, format="%Y-%m-%d %H:%M:%S"))
#'
#'#run function and give it to df
#'df<-gfr(patients=gfrx, labs=gfry, ID.patients="PAT_ENC_CSN_ID", ID.labs="PAT_ENC_CSN_ID",
#'lab.name="COMPONENT_NAME", ord.value="ORD_VALUE",result.date="date",
#'gender="SEX_CD", race="RACE_CD", age="age")
#'
#'#if there are no lab names
#'gfrnonames<-gfry
#'gfrnonames$COMPONENT_NAME<-NULL
#'testgfr<-gfr(patients=gfrx, labs=gfrnonames, ID.patients="PAT_ENC_CSN_ID", ID.labs="PAT_ENC_CSN_ID",
#'lab.name="none", ord.value="ORD_VALUE",result.date="date",
#'gender="SEX_CD", race="RACE_CD", age="age")


#'@export

gfr<-function(patients=patients, labs=labs, ID.patients="PAT_ENC_CSN_ID", ID.labs="PAT_ENC_CSN_ID",
              lab.name="COMP_LAB_NAME", ord.value="ORD_VALUE",result.date="RESULT_DATE_TIME",
              gender="SEX", race="RACE", age="AGE"){
  if(lab.name=="none"){
   labs<-labs[(labs[,ID.labs] %in% patients[,ID.patients]),]
   #remove non numeric values
   creatinine<-labs
   creatinine<-creatinine[!is.na(creatinine[,ID.labs]),]
   creatinine[,ord.value] <- withCallingHandlers(suppressWarnings(as.numeric(creatinine[,ord.value])))
   creatinine <-creatinine[!is.na(creatinine[,ord.value]),]

   #get most recent at CSN
   #class(creatinine[,result.date]) = 'POSIXt'
   creatinine<-creatinine[order(creatinine[,result.date], decreasing=T),]
   creatinine<-creatinine[duplicated(creatinine[,ID.labs])==F,]

   ## merge with patients
   patients.creat <- merge(patients, creatinine[,c(ID.labs, ord.value, result.date)],
                           by.x=ID.patients, by.y=ID.labs, all.x=T, all.y=F)

   #Create components of GFR
   patients.creat$kappa<-ifelse((patients.creat[,gender]=="Male" |
                                   patients.creat[,gender]=="M"), 0.9, 0.7)		 #consider incorporating U
   patients.creat$alpha<-ifelse((patients.creat[,gender]=="Male" |
                                   patients.creat[,gender]=="M"), -0.411, -0.329)
   patients.creat$ckd.race<-ifelse((patients.creat[,race]=="Black or African American" |
                                      patients.creat[,race]=="B"), 1.159, 1)
   patients.creat$ckd.sex<-ifelse((patients.creat[,gender]=="Male" |
                                     patients.creat[,gender]=="M"), 1, 1.018)
   patients.creat[,age]<-as.numeric(patients.creat[,age])

   #GFR
   patients.creat$GFR<-sapply(1:nrow(patients.creat), function (x)
     (141 * ((min((patients.creat[,ord.value][x]/patients.creat$kappa[x]), 1)^patients.creat$alpha[x]) *
               (max((patients.creat[,ord.value][x]/patients.creat$kappa[x]), 1)^(-1.209)) *
               (0.993^patients.creat[,age][x]) *
               patients.creat$ckd.sex[x] * patients.creat$ckd.race[x])))

   patients.creat[,c("kappa","alpha","ckd.race","ckd.sex")]<-as.list(NULL)
   patients.creat$CREAT_VALUE<-patients.creat[,ord.value]
   patients.creat[,c(ord.value,result.date)]<-as.list(NULL)
   output<-(patients=patients.creat)

  }else{
    labs<-labs[(labs[,ID.labs] %in% patients[,ID.patients]),]
    creatinine<-labs[(labs[,lab.name]=="CREATININE"|
                          labs[,lab.name]=="CREATINE, SERUM"|
                          labs[,lab.name]=="CREATININE LEVEL"),] #get only these names, need to make sure mg/dL

    #remove non numeric values
    creatinine<-creatinine[!is.na(creatinine[,ID.labs]),]
    creatinine[,ord.value] <- suppressWarnings(as.numeric(creatinine[,ord.value]))
    #remove values outside of acceptable range
    #creatinine <-creatinine[creatinine[,ord.value]<20,] #check for reference range outlier
    creatinine <-creatinine[!is.na(creatinine[,ord.value]),]

    #get most recent at CSN
    #class(creatinine[,result.date]) = 'POSIXt'
    creatinine<-creatinine[order(creatinine[,result.date], decreasing=T),]
    creatinine<-creatinine[duplicated(creatinine[,ID.labs])==F,]

    ## merge with patients
    patients.creat <- merge(patients, creatinine[,c(ID.labs, ord.value, result.date)],
                            by.x=ID.patients, by.y=ID.labs, all.x=T, all.y=F)

    ## GFR by the CKD epi equation
    patients.creat$kappa<-ifelse((patients.creat[,gender]=="Male" |
                                    patients.creat[,gender]=="M"), 0.9, 0.7)		 #consider incorporating U
    patients.creat$alpha<-ifelse((patients.creat[,gender]=="Male" |
                                    patients.creat[,gender]=="M"), -0.411, -0.329)
    patients.creat$ckd.race<-ifelse((patients.creat[,race]=="Black or African American" |
                                       patients.creat[,race]=="B"), 1.159, 1)
    patients.creat$ckd.sex<-ifelse((patients.creat[,gender]=="Male" |
                                      patients.creat[,gender]=="M"), 1, 1.018)
    patients.creat[,age]<-as.numeric(patients.creat[,age])

    #This function is kind of weird - this is the last piece
    patients.creat$GFR<-sapply(1:nrow(patients.creat), function (x)
      (141 * ((min((patients.creat[,ord.value][x]/patients.creat$kappa[x]), 1)^patients.creat$alpha[x]) *
                (max((patients.creat[,ord.value][x]/patients.creat$kappa[x]), 1)^(-1.209)) *
                (0.993^patients.creat[,age][x]) *
                patients.creat$ckd.sex[x] * patients.creat$ckd.race[x])))

    patients.creat[,c("kappa","alpha","ckd.race","ckd.sex")]<-as.list(NULL)
    patients.creat$CREAT_VALUE<-patients.creat[,ord.value]
    patients.creat[,c(ord.value,result.date)]<-as.list(NULL)
    output<-(patients=patients.creat)


}
}
