#'Missing Data Table
#'@description Generates data frame of missing data tabulations.
#'Missing data must be defined as NA in data set prior to use.
#'@param dataFrame Data set with missing values defined as NA
#'@param vars Variables in dataFrame for which to calculate missing data.
#'If blank, will use all names in dataFrame. Class may be integer, numeric, date, or string
#'@param by.var Name of variable in dataFrame used to calculate missing by category. If blank, by.var will not be used
#'@param rounded A numeric value specifying number of decimals for percent missing
#'@param counts If counts="combined", percent and n missing will be combined as a single, character column.
#'If counts="separate", percent and n missing will be separate, numeric columns. If not defined, counts="separate"
#'@return A data frame containing n number of missing values per variable
#'and percentage of missing values per variable (n / total number of observations per variable.)
#'The last row, "total_obs_miss_and_nonmiss", does not adhere to column name, and indicates total number of observations per variable. This includes both non-missning and missing values.
#'@author Kristin Lenoir \email{klenoir@wakehealth.edu}
#'@keywords missing data
#'@examples
#'df<-missingdata(miss.dat)
#'
#'#missing data by technician with percent and n missing combined, rounding to 2 digits
#'df<-missingdata(miss.dat, by.var="technician",counts="combined", rounded=2)
#'
#'#missing data for only "lab_value_one" and "month"
#'df<-missingdata(miss.dat, vars=c("lab_value_one","month"))
#'
#'#replace all values of 3 in miss.dat with NA
#'miss.dat[miss.dat == 3] <- NA
#'#total n missing data in miss.dat
#'sum(is.na(miss.dat))
#'#total percent missing data in miss.dat (n missing/(rows*columns))
#'sum(is.na(miss.dat))/(dim(miss.dat)[1]*dim(miss.dat)[2])*100

#'@export

##MISSING DATA FUNCTION
missingdata<-function(dataFrame, vars=NULL, by.var = NULL, rounded=1, counts=c("separate","combined")){

  #warnings
    if (is.data.frame(dataFrame))
        x <- as.matrix(dataFrame)
  #stop if this
   if (!is.array(x) || length(dn <- dim(x)) < 2L)
        stop("'dataFrame' must be an array of at least two dimensions")
    if(length(vars)==1)
        stop("Vars must be NULL or greater than legnth of one")

  #vars
    dataFrame<-as.data.frame(dataFrame) #make dataframe

    #generate selected based upon vars and by.var input
    if(!is.null(vars) & !is.null(by.var)){selected<-names(dataFrame[,vars])
                                          selected<-selected[!selected %in% by.var]
        }else if(!is.null(vars) & is.null(by.var)){selected<-names(dataFrame[,vars]) #will not work if only one input
        }else if(is.null(vars) & !is.null(by.var)){selected<-names(dataFrame)[!names(dataFrame) %in% by.var]
        }else{selected<-names(dataFrame)} #if vars and by vars are null

	   #get rows
     r<-nrow(dataFrame)
     #counts logic.  get separate if nothing is specified
     if(is.null(counts) || !counts=="combined"){counts<-"separate"}else{counts<-"combined"}

	#########################
	#Run totals for selected#
	#########################
	per<-list()
	nl<-list()
	for(i in 1:ncol(dataFrame[,selected])){
	  per[[i]]<-round((as.numeric(sum(is.na(dataFrame[,selected][i])))/r)*100,rounded)
			names(per)[i]<-names(dataFrame[,selected][i])
		 nl[[i]]<-sum(is.na(dataFrame[,selected][i]))
		 	names(nl)[i]<-names(dataFrame[,selected][i])
			total_observations<-nrow(dataFrame[,selected])
		}
	#define totals totals should be selected or combined
	if(counts=="combined"){
	          totals<-as.data.frame(cbind(per,nl))
			    totals$percent_n_missing<-paste0(totals$per," (", totals$nl, ")")
			      totals[,c("per","nl")]<-as.list(NULL)
				  totals[nrow(totals)+1,]<-total_observations
				  rownames(totals)[length(rownames(totals))]<-"total_obs_miss_and_nonmiss"

		  }else{totals<-as.data.frame(cbind(per,nl))	#keep seeparate
	          names(totals)<-c("percent_missing","n_missing")
			  	 totals[nrow(totals)+1,]<-c(NA,total_observations)
				  rownames(totals)[length(rownames(totals))]<-"total_obs_miss_and_nonmiss"
				  totals[,names(totals)]<-sapply(totals[,names(totals)], function(x) as.numeric(x))
		        }

	################
	##By Variable##
	################
	if(is.null(by.var)){  #if no by variable, output totals
		combined<-totals

		}else{
			  dataFrame[,by.var][is.na(dataFrame[,by.var])]<-"NA" #count NA's as category
		    bylevels<-levels(factor(dataFrame[,by.var], exclude = NULL))  #first step in subset
		  	subsets<-split(dataFrame[,selected],dataFrame[,by.var])#subset by "by", give to ist

		  	  #create holding lists
	      x<-list()
	      xn<-list()
		    total_observations<-as.vector(rep(NA,length(subsets)))

	  if(counts=="combined" | is.null(counts)){

	        for (i in 1:length(subsets)){#for each subset defined, run this function
	          x[[i]]<-sapply(subsets[[i]][selected], function(x) paste0(round(((as.numeric(sum(is.na(x)))/length(x))*100),rounded)	                                                                   ,
	                                                             "(",round(as.numeric(sum(is.na(x))),1),")"))
				    names(x)[i]<-paste0(bylevels[i],"_","percent_n_missing")

			      x[[i]]<-sapply(subsets[[i]][selected], function(x) paste0(round(((as.numeric(sum(is.na(x)))/length(x))*100),rounded)	                                                                   ,
	                                                             "(",round(as.numeric(sum(is.na(x))),1),")"))
				    total_observations[i]<-dim(subsets[[i]][selected])[1]
	            }

	        by.vars<-as.data.frame(x) #together
	        k<-names(x)
	        by.vars[,k]<-sapply(by.vars[,k], function(x) as.character(x))
	        by.vars[nrow(by.vars)+1,]<-as.character(total_observations)
	        rownames(by.vars)[length(rownames(by.vars))]<-"total_obs_miss_and_nonmiss"
	        combined<-as.data.frame(cbind(by.vars,totals))

	        }else{

			for (i in 1:length(subsets)){  #for each subset defined, run this function
		      x[[i]]<-sapply(subsets[[i]][selected], function(x) round(((as.numeric(sum(is.na(x)))/length(x))*100),rounded)) #calculate percent missing for each variable
		              names(x)[i]<-paste0(bylevels[i],"_","percent_missing")
		      xn[[i]]<-sapply(subsets[[i]][selected], function(x) round(as.numeric(sum(is.na(x))),rounded)) #calculate the raw n missing
		              names(xn)[i]<-paste0(bylevels[i],"_","n_missing")
		      total_observations[i]<-dim(subsets[[i]][selected])[1]
					  }

	          by.vars<-cbind(as.data.frame(x),as.data.frame(xn))
			  by.vars[nrow(by.vars)+1,]<-c(as.vector(rep(NA,length(subsets))),as.numeric(total_observations))
	          rownames(by.vars)[length(rownames(by.vars))]<-"total_obs_miss_and_nonmiss"
		      combined<-as.data.frame(cbind(by.vars,totals))
		            }}


	output<-combined

    }
