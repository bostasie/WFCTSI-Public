#' @title GFR Creatinine Labs Data Set
#'
#' @description A data from containing a artificial list of patients and creatinine lab values
#' @name gfry
#' @keywords datasets
#' @docType data
#' @format A data frame
#' @keywords datasets
NULL
