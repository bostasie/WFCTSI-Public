#' @title ICD Data Set to demonstrate CCI function
#'
#' @description A data from containing a artificial list of patients and ICD codes used to demonstrate the cci function
#' @name icd
#' @keywords datasets
#' @docType data
#' @format A data frame
#' @keywords datasets
NULL
