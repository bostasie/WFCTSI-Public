#' @title GFR Patient Data Set
#'
#' @description A data from containing a artificial list of patients and demographics
#' @name gfrx
#' @keywords datasets
#' @docType data
#' @format A data frame
#' @keywords datasets
NULL
