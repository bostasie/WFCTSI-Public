#' @title Data Set with Missing Values
#'
#' @description A data from containing data to demonstrate the missingdata function
#' @name miss.dat
#' @keywords datasets
#' @docType data
#' @format A data frame
#' @keywords datasets
NULL
